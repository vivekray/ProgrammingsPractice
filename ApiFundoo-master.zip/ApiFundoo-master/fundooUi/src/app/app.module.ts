import { BrowserModule } from '@angular/platform-browser';
import { NgModule}       from '@angular/core';
import { CardComponent } from './Component/card/card.component';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './Component/register/register.component';
import { DashboardComponent } from './Component/dashboard/dashboard.component';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule, MatInputModule, MatMenuModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import {MatDividerModule} from '@angular/material/divider';
import { MatToolbarModule } from '@angular/material/toolbar';
import { HttpClientModule } from '@angular/common/http';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';
/////////////////////////////////////////////////////

import {A11yModule} from '@angular/cdk/a11y';
import {PortalModule} from '@angular/cdk/portal';
import {CdkStepperModule} from '@angular/cdk/stepper';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatBadgeModule} from '@angular/material/badge';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDialogModule} from '@angular/material/dialog';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatGridListModule} from '@angular/material/grid-list';

import {MatListModule} from '@angular/material/list';
import {MatNativeDateModule, MatRippleModule} from '@angular/material/core';
import {MatSidenavModule} from '@angular/material/sidenav';


////////////////////////////////////////////////////



import { ForgetComponent } from './Component/forget/forget.component';
import { ResetComponent } from './Component/reset/reset.component';
import { LableComponent } from './Component/lable/lable.component';
import { NoteComponent } from './Component/note/note.component';
import { ToolbaarComponent } from './Component/toolbaar/toolbaar.component';
import { TrashComponent } from './Component/trash/trash.component';
import { CollabaratorComponent } from './Component/collabarator/collabarator.component';
import { AddNoteComponent } from './Component/add-note/add-note.component';
import { GetNoteComponent } from './Component/get-note/get-note.component';
import { NotePropertyComponent } from './Component/note-property/note-property.component';
import { ArchievedComponent } from './Component/archieved/archieved.component';
import { DialogBoxComponent } from './Component/dialog-box/dialog-box.component';
import { ReminderComponent } from './Component/reminder/reminder.component';
import { DialogBoxLabelComponent } from './Component/dialog-box-label/dialog-box-label.component';
import { PinnedComponent } from './Component/get-pin-note/pinned/pinned.component';
import { GetPinnedComponent } from './Component/get-pinned/get-pinned.component';




@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    CardComponent,
    LoginComponent,
    DashboardComponent,
    ForgetComponent,
    ResetComponent,
    LableComponent,
    NoteComponent,
    DialogBoxComponent,
    ToolbaarComponent,
    TrashComponent,
    CollabaratorComponent,
    AddNoteComponent,
    GetNoteComponent,
    NotePropertyComponent,
    ArchievedComponent,
  
    TrashComponent,
    ReminderComponent,
    DialogBoxLabelComponent,
    PinnedComponent,
    GetPinnedComponent,
  
   
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatCardModule,
    MatInputModule, 
    MatMenuModule,
    MatToolbarModule,
    MatDividerModule,
    FormsModule, 
    ReactiveFormsModule,
    FlexLayoutModule,
    MatIconModule,
    MatButtonModule,
    HttpClientModule,
    MatSnackBarModule,
    RouterModule,
    BrowserAnimationsModule,
    /////////////////////////////////////////////////////
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    MatFormFieldModule,
    MatButtonModule,
    MatCardModule,
    A11yModule,
    CdkStepperModule,
    CdkTableModule,
    CdkTreeModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatSidenavModule,
   
   
  

    //////////////////////////////////////////////////////////
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
