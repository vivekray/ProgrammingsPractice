export class Collaborate {
    emailid:string;
    noteid:any;
}
