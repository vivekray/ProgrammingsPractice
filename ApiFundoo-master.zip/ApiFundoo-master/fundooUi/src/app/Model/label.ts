export class Label {
    name:String
}
