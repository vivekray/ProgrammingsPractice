export class Note {
    id:string;
    userId:String;
    title:String;
    description:String;
    reminder:String;
    color:String;
    image:String;
    archive:Boolean;
    pinned:Boolean;
    trash:Boolean;
    label:Boolean;
}

