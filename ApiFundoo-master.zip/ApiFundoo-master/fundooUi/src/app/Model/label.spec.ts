import { Label } from './label';

describe('Label', () => {
  it('should create an instance', () => {
    expect(new Label()).toBeTruthy();
  });
});
