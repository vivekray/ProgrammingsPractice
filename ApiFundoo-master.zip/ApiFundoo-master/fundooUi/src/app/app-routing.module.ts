import { NgModule, ContentChildren } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CardComponent } from './Component/card/card.component';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './Component/register/register.component';
import { DashboardComponent } from './Component/dashboard/dashboard.component';
import { ForgetComponent } from './Component/forget/forget.component';
import { ResetComponent } from './Component/reset/reset.component';
import { AddNoteComponent } from './Component/add-note/add-note.component';
import { NoteComponent } from './Component/note/note.component';

import { GetNoteComponent } from './Component/get-note/get-note.component';
import { ArchievedComponent } from './Component/archieved/archieved.component';
import { TrashComponent } from './Component/trash/trash.component';
import {DialogBoxComponent} from './Component/dialog-box/dialog-box.component'
import { ReminderComponent } from './Component/reminder/reminder.component';
import { DialogBoxLabelComponent } from './Component/dialog-box-label/dialog-box-label.component';
import { CollabaratorComponent } from './Component/collabarator/collabarator.component';

const routes: Routes = [
   { 
     path: '', 
    redirectTo: '/login',
    pathMatch: 'full' 
  },

  {
    path: 'login',
    component : LoginComponent
  },
  {
   path:'reset/:token',
   component: ResetComponent
  },


  { 
    path: 'card', 
    component: CardComponent 
  },
  {
    path: 'register',
    component:RegisterComponent 
  },
  {
    path:'forget',
    component:ForgetComponent
  },
  

  {
    path:'dashboard',
    component:DashboardComponent,
    children: [
      { path: '', redirectTo:
       'notes',pathMatch: 'full' 
      },
      {
        path:'notes',
        component: NoteComponent
      },

      {
        path:'getAllArchived',
        component: ArchievedComponent
      },
      {
        path:'getAllTrashed',
        component:TrashComponent
      },
      {
        path:'notes/:_id',
        component:DialogBoxComponent
      },
      {
        path:'getAllReminder',
        component:ReminderComponent
      },
      { path:'label',component:DialogBoxLabelComponent},
      { path:'collab',component:CollabaratorComponent},
      
      
    ]
  

  },
  {
    path:'note',
    component:AddNoteComponent
  },
  {
    path:'getnote',
    component: GetNoteComponent
  },
  



 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }