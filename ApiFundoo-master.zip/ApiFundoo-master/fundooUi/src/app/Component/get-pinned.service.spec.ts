import { TestBed } from '@angular/core/testing';

import { GetPinnedService } from './get-pinned.service';

describe('GetPinnedService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GetPinnedService = TestBed.get(GetPinnedService);
    expect(service).toBeTruthy();
  });
});
