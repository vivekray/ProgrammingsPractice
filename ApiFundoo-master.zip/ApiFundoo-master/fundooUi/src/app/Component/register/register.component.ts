import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/userService/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private router: Router,
    private userService: UserService) { }

  ngOnInit() {
    //this.registerForm = this.formBuilder.group({
    this.registerForm = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z ]*')]),
      lastName: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z ]*')]),
      mobileNumber: new FormControl('', [Validators.required, Validators.minLength(9), Validators.pattern('[789]{1}[0-9]{9}')]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      confirm: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
    });
  }

  register() {
    try {
      if (this.registerForm.controls.password.value === this.registerForm.controls.confirm.value) {
        const data = {
          "firstName": this.registerForm.controls.firstName.value,
          "lastName": this.registerForm.controls.lastName.value,
          "mobileNumber": this.registerForm.controls.mobileNumber.value,
          "email": this.registerForm.controls.email.value,
          "password": this.registerForm.controls.password.value
        };
        ////User CAlling Services 
        this.userService.registration(data).subscribe((user) => {
          console.log("data-->", user);
          this.snackBar.open('Registered Successfully!', 'Ok', { duration: 3000 });

        }, (error: any) => {
          console.log(error);
          this.snackBar.open('User Exist Already!', 'Ok', { duration: 3000 });
        //  this.snackBar.open(error.error.description, 'error', { duration: 3000 });
        });

      } else {
        console.log("fail password does not matched");
        this.snackBar.open("Registration fail password & confirm password does not match..!!!", "", { duration: 2000 });
      }
    } catch (err) {
      console.log("err in registeration", err)
    }
  }


}
