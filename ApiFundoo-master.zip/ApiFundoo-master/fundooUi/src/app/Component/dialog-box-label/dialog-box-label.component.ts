import { Component, OnInit, Input, Inject } from '@angular/core';
import { Label } from 'src/app/Model/label';
import { MatSnackBar, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { LabelService } from 'src/app/service/label/label.service';

@Component({
  selector: 'app-dialog-box-label',
  templateUrl: './dialog-box-label.component.html',
  styleUrls: ['./dialog-box-label.component.scss']
})
export class DialogBoxLabelComponent implements OnInit {
  @Input() labelData: any
  labels: any[];
  label: Label = new Label();

  constructor(private snackbar: MatSnackBar,
    private labelService: LabelService,
    public dialogBox: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.getLabel()
  }

  createlabel() {

    this.labelService.createLabel( this.label,'label/create').subscribe(
      (response: any) => {
        console.log("response --------------", response);
        this.snackbar.open(
          "Label created Successfully",
          "undo",
          { duration: 2500 }
        )
      },
      (error) => {

        this.snackbar.open(
          "Label creation Failed",
          "undo",
          { duration: 2500 }
        )
      }
    )
  }

  getLabel() {
    console.log("get Lable")
    this.labelService.getLabel('label/getAllLabel').subscribe(
      (response: any) => {
        console.log("RESPONSE ::::::::", response)
        this.labels = response.data
        console.log("this.labels", this.labels)
        console.log("RESPONSE ::::::::", response.data)
      },
      (err: any) => {
        console.log("error", err)
      }
    )
  }
  onEditLabel(labels) {

    console.log("DATA :::",labels);
    var label = 
    {
      "id" : labels[0].id
      
    }
    console.log("label",label)
  
      this.labelService.updateLabel(label,'/label/'+label.id+'/update',).subscribe(
        response => {
  
         //console.log("hjerfgjhaewvgfhjaw",response);
          this.snackbar.open(
            "Note is updated Successfully",
            "undo",
            { duration: 2500 }
          )
        },
        error =>
        {
          this.snackbar.open(
            "Note is updation Failed",
            "undo",
            { duration: 2500 }
          )
        }
    
      )
    }

    deleteLabel(label) {
      console.log(label._id);
    
      this.labelService.deleteLabel('/label/'+ label._id).subscribe(
        (response: any) => {
       
          console.log(response);
            this.snackbar.open(
              "Label deleted Successfully",
              "undo",
              { duration: 2500 }
            )
          },
          error =>
          {
           
            this.snackbar.open(
              "Label deletion Failed",
              "undo",
              { duration: 2500 }
            )
          
  
        }
      )
  
    }

}
