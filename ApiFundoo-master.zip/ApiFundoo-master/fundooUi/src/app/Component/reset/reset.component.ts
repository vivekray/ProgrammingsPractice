import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/service/userService/user.service';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.scss']
})
export class ResetComponent implements OnInit {
  [x: string]: any;
  resetForm: FormGroup;
  token: string;

  constructor(private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private router: Router, private route: ActivatedRoute,
    private userService: UserService) {
  }

  ngOnInit() {
    this.token = this.route.snapshot.paramMap.get("token")
    //this.registerForm = this.formBuilder.group({
    this.resetForm = new FormGroup({
      password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      confirm: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
    });
  }

  reset() {
    try {
      //let tocken=new HttpParams().get('token')
      if (this.resetForm.controls.password.value === this.resetForm.controls.confirm.value) {
        const data = {
          "newPassword": this.resetForm.controls.password.value
        };
        ////User CAlling Services 
        this.userService.reset(data, this.token).subscribe((user) => {
          console.log("data-->", user);
          let confirm = this.snackBar.open('Updated Successfully!', 'Ok', { duration: 5000 });
          confirm.onAction().subscribe(() => {
            this.router.navigate(['./login']);
          })
          //confirm.afterDismissed().subscribe((action) => {
          //   if (!action)
          //   this.router.navigate(['./reset']);
          // });



        }, (error: any) => {
          console.log(error);
          this.snackBar.open('Not Updated!', 'Ok', { duration: 3000 });
          //  this.snackBar.open(error.error.description, 'error', { duration: 3000 });
        });

      } else {
        console.log("fail password does not matched");
        this.snackBar.open("Registration fail password & confirm password does not match..!!!", "", { duration: 2000 });
      }
    } catch (err) {
      console.log("err in registeration", err)
    }

  }
}
