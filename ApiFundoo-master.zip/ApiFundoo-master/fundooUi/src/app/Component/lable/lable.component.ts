import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lable',
  templateUrl: './lable.component.html',
  styleUrls: ['./lable.component.scss']
})
export class LableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
