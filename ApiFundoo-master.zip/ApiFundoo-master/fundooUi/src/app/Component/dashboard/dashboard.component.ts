import { Component, OnInit } from '@angular/core';
import {MediaMatcher} from '@angular/cdk/layout';
import {ChangeDetectorRef,  OnDestroy} from '@angular/core';
import { Router } from '@angular/router';
import { LabelService } from 'src/app/service/label/label.service';
import { DialogBoxLabelComponent } from '../dialog-box-label/dialog-box-label.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  private popup: boolean;
  labels: any[] = [];
  mobileQuery: MediaQueryList;
  fillerContent = Array.from({length: 50});

  private _mobileQueryListener: () => void;
  constructor(
    private router:Router,
    changeDetectorRef: ChangeDetectorRef, 
    media: MediaMatcher,
     private labelService: LabelService,
     public dialog:MatDialog
     ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit() {
    this.getLabel();
  }


  getLabel() {
    console.log("get Lable")
    this.labelService.getLabel('label/getAllLabel').subscribe(
      (response: any) => {
        console.log("RESPONSE ::::::::", response)
        this.labels = response.data
        console.log("this.labels", this.labels)
        console.log("RESPONSE ::::::::", response.data)
      },
      (err: any) => {
        console.log("error", err)
      }
    )
  }

  opendialogLabel(label) {

     console.log("ITEMS ::::::",label)
    const dialogRef = this.dialog.open(DialogBoxLabelComponent,
      {

        width: '500px',
         height: '500px',
         
         data: {
          label: label.label,
          _id: label._id
          
         }
      }
    );
    dialogRef.afterClosed().subscribe(result => {
       console.log(`dialog result:${result}`);
    });

  }



  refresh(): void {
    window.location.reload();
  }
  Logout():void{
    this.router.navigate(['./login']);
    localStorage.removeItem('FundooToken')
   
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  onPopup() {

    this.popup = true;                           
  }

  onPopupNote() {

    this.popup = false;                           
  }

}
