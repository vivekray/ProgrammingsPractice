import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
//import { Note } from '../../note';
import { MatSnackBar } from '@angular/material';
import { NoteService } from 'src/app/service/note/note.service';
import { DialogBoxComponent } from '../dialog-box/dialog-box.component';
import {Input, Output, EventEmitter } from '@angular/core';
import { Note } from 'src/app/Model/note';
import { CollabaratorComponent } from '../collabarator/collabarator.component';
import { LabelService } from 'src/app/service/label/label.service';
import { CollaborateService } from 'src/app/service/collaborate/collaborate.service';
import { Collaborate } from 'src/app/Model/collaborate';



//import { MatDialog } from '@angular/material/dialog';
 
@Component({
  selector: 'app-get-note',
  templateUrl: './get-note.component.html',
  styleUrls: ['./get-note.component.scss']
})
export class GetNoteComponent implements OnInit {
  @Output() event = new EventEmitter();
  note: Note = new Note();
  noteid:string;
  items:string;
  private popup: boolean=false;
  date: Date = new Date();
  collabs:Collaborate=new Collaborate();
  notes : any[]=[];
  collab:any[]=[];
  sample:any;
  trash: Boolean;
  archive: Boolean;
  labels: any[];
  color: any[];
  views: any;
  allign: string = '';
  // wrap:string='wrap';
  direction1: string = 'wrap';

  direction: string = "row";
  //res1: unknown;
  constructor(
   
    private snackBar: MatSnackBar,
    private noteService: NoteService,
    public matDialog: MatDialog,
    private labelService: LabelService,
    private collabService: CollaborateService,
  ) { }

  ngOnInit() {
    this.getNote();
    this.getColab();
  }
  // addLabel(labels, items) {
  //   console.log("Add Label to Note");
  //   console.log("NoteId", items);
  //   console.log("labelId", labels);
  //   var data = {
  //     "id": items._id,
  //     "label": labels[0]._id
  //   }
  //   console.log("data ::::", data)
  //   this.noteService.addLabel("/notes/:_id/label", data).subscribe(
  //     (response: any) => {

  //       console.log("label is added to note");
  //       this.snackBar.open(
  //         "label is added to note successfully",
  //         "undo",
  //         { duration: 2500 }
  //       )
  //     },
  //     error => {
  //       console.log("label add failed");
  //       this.snackBar.open(
  //         "label addtion failed",
  //         "undo",
  //         { duration: 2500 }
  //       )
  //     }
  //   )
  // }


  
getNote() {
  this.noteService.getAllNotes('notes/list').subscribe(
    (response: any) => {
    
      this.notes = response;
      console.log(this.notes)
      // var sample=response.data
      //   console.log("Notes are:",sample);
      // sample.forEach(element=>{
      //   this.notes.push(element);
      // })
      console.log("Array",this.notes);
    }
  )
} 
openDialog(items: any) {
  const dialogRef = this.matDialog.open(DialogBoxComponent, {
    width: '500px', height: '190px',
    data: {
      title: items.title,
      description: items.description,
      id: items.id
    }
  });
  dialogRef.afterClosed().subscribe(result => {
    console.log(`dialog result:${result}`);
  });

}

opendialogCollab(items: any) {

  console.log("ITEMS ::::::",items)
 const dialogRef = this.matDialog.open(CollabaratorComponent,
   {

    width: '300px', height: '290px',
      
      data: {
        id: items.id
       
      }
   }
 );
 dialogRef.afterClosed().subscribe(result => {
    console.log(`dialog result:${result}`);
 });

}

// onArchive(items,$event) {
//   this.archive = $event
//   var data = {
//     "_id" : items.note_id,
//     "archive" :
//  }


colorCodes =
  [
    [
      { name: "white", hexcode: "#ffffff" },
      { name: "lightGreen", hexcode: "#ccff8f" },
      { name: "purple", hexcode: "#d8aefb" },
      { name: "red", hexcode: "#f28b82" },
    ],
    [
      { name: "Teal", hexcode: "#a7feeb" },
      { name: "pink", hexcode: "#fdcfe8" },
      { name: "orange", hexcode: "#fbbd03" },
      { name: "blue", hexcode: "#cbf0f8" },
    ],
    [
      { name: "brown", hexcode: "#e6c9a8" },
      { name: "yellow", hexcode: "#fff474" },
      { name: "darkBlue", hexcode: "#aecbfa" },
      { name: "gray", hexcode: "#e8eaed" }
    ]
  ]
changeColor(color, items) {
  var data = {
    "color": color,
    "id": items.id
  }
  console.log("color",color)

  this.noteService.postColor(data,'notes/color/'+this.noteid).subscribe(
    (response: any) => {
      console.log(response);
      this.event.emit([]);
      this.snackBar.open(
        'note color updated Successfully..', 
        'End now', 
        { duration: 1000 });
        window.location.reload();
      
    },
    error => {
      console.log(error); 
      this.snackBar.open(
        'note color not updated', 
        'End now', 
        { duration: 1000 });
     }) 
  }


  getLabel() {
    console.log("get Lable")
    this.labelService.getLabel('label/getAllLabel').subscribe(
      (response: any) => {
        console.log("RESPONSE ::::::::", response)
        this.labels = response.data
        console.log("this.labels", this.labels)
        console.log("RESPONSE ::::::::", response.data)
      },
      (err: any) => {
        console.log("error", err)
      }
    )
  }

  getColab() {
    console.log("get Collaborators--------")
    this.collabService.getCollab('collaborator/fetchColab/'+this.items).subscribe(
      (response: any) => {
        console.log("RESPONSE ::::::::", response)
        this.collab = response
        console.log("this.collab==", this.collab)
        console.log("RESPONSE ::::::::", response.data)
      },
      (err: any) => {
        console.log("error", err)
      }
    )
  }



getAllArchiveNotes() {
  this.noteService.getAllArchiveNotes('/notes/getAllArchived').subscribe(
    (response: any) => 
    {
    console.log(response);
    //this.note = response;
   
    var sample=response.data
      console.log("Notes are:",sample);
    sample.forEach(element=>{
      this.notes.push(element);
    })
    console.log("Array",this.notes);
  })
}

onPin(items) {
  this.noteService.archiveNote('notes/pin/'+items.id).subscribe(

    (response: any) => {
      
        this.snackBar.open(
          "Note is Pinned",
          "null",
          { duration: 2500 }
        )
        window.location.reload();
      },
      (error: any) =>
      {
        this.snackBar.open(
          "Notes Pinned failed",
          "undo",
        )
        }
  )
}


onArchive(items) {
  this.noteService.archiveNote('notes/archieve/'+items.id).subscribe(

    (response: any) => {
      
        this.snackBar.open(
          "Note is Archived",
          "null",
          { duration: 2500 }
        )
        window.location.reload();
      },
      (error: any) =>
      {
        this.snackBar.open(
          "Notes unarchived failed",
          "undo",
        )
        }
  )
}

trashNote(items,noteindex) {
  this.notes.splice(noteindex, 1);
  console.log("TRASHNOTE noteId :::::::",items.id)
  this.noteService.trashNote('notes/trash/'+items.id).subscribe(

    (response: any) => {
      
        this.snackBar.open(
          "Note Trashed",
          "null",
          { duration: 2500 }
        )
       // window.location.reload();
      },
      (error: any) =>
      {
        this.snackBar.open(
          "Notes untrash failed",
          "undo",
        )
        }
   
  )
}
setToday(items) {

  console.log("data in reminder",items);
  console.log("Todays date is been set ")
  const date = new Date().toDateString();
  console.log("Date added:" + date)
  let reminderDate = date + ' 08:00:00';
  console.log('in reminder1==>', reminderDate);
  let data1 = 
  {
    "id" : items.id,
    "reminder" : reminderDate
  }
  this.noteService.setReminder( data1,"notes/reminder/"+data1.id).subscribe(
    (response: any) => 
    {
      console.log("Note is remaindered successfully")
    })


}

setTomorrow(items) {
  
  console.log("Tomorrow date is been set ")
  var date = new Date();
     date.setDate(date.getDate()+1)
  //console.log("Date added:" + date)
  let reminderDate = date.toDateString() + ' 08:00:00';

  
  console.log(this.date.toString());
  var data1 =
  {
    "_id" : items.id,
    "reminder" : reminderDate
  }
  this.noteService.setReminder( data1,"notes/reminder/"+data1._id).subscribe(
    (response: any) => 
    {
      console.log("Note is remaindered successfully")
    }
    )
}


setWeekly(items) 
{
  console.log(items.noteId);
  console.log("After week date is been set ")
  this.date.setDate(this.date.getDate() + 7);
  console.log(this.date.toString());
  let reminderDate = this.date.toDateString() + ' 08:00:00';
  var data1 =
  {
    "id" : items.id,
    "reminder" : reminderDate
  }
  this.noteService.setReminder(data1,"notes/reminder/"+ data1.id).subscribe(
    (response: any) => 
    {
      console.log("Note is reminder successful");
      console.log(response)
    }
  )
}


deleteReminder(items)
{
  var reminder=null
 
 
  this.noteService.deleteReminder("notes/deletereminder/"+items.id).subscribe(
    (response: any) => 
    {
      console.log("reminder is deleted successful");
      console.log(response)
      window.location.reload();
    }
  )
}

onPopup(){
  this.popup=true;
}

}



 

