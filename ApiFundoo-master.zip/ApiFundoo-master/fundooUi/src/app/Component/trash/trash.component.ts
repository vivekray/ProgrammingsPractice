import { Component, OnInit } from '@angular/core';
import { Note } from 'src/app/note';
import { MatSnackBar, MatDialog } from '@angular/material';
import { NoteService } from 'src/app/service/note/note.service';

@Component({
  selector: 'app-trash',
  templateUrl: './trash.component.html',
  styleUrls: ['./trash.component.scss']
})
export class TrashComponent implements OnInit {
  note : Note = new Note();
  trash : boolean
  notes : any[]=[];
  sample:any;
  trashed:string;
  constructor(private snackBar: MatSnackBar, 
    private noteService: NoteService, public matDialog : MatDialog) { }

  ngOnInit() {
    this.getAllTrashedNotes();
  }
  getAllTrashedNotes(){
    this.noteService.getAllTrashedNotes('notes/trashed').subscribe(
      (response: any) => 
      {
        console.log(response);
        //this.note = response;
        this.notes = response;
        console.log(this.notes)
       
        console.log("Array",this.notes);
        if(this.notes.length<1)
        {
          this.trashed="No Notes In Trash";
        }
    })

  }
  deleteNote(items,noteindex) {
    this.notes.splice(noteindex, 1);
    console.log("note delete permanently");
    console.log("Note ID" + items._id);
    this.noteService.deleteNote('/notes/'+items._id).subscribe(
      
      (response: any) => {
        console.log("hello");
          this.snackBar.open(
            "Note deleted Successfully",
            "undo",
            { duration: 2500 }
          )
        },
          (error: any) => {
          this.snackBar.open(
            "Notes deletion  failed",
            "undo",
          )
        }

      
    )
  }

   /**
     * onClick function for trash note
     * @param items 
     * @param $event 
     */
   // trashNote(items,$event) {
    trashNote(items,noteindex) {

     // this.trash = $event
      this.notes.splice(noteindex, 1);
      var data = {
        "trash" : false,
      }
      console.log("TRASHNOTE noteId :::::::",data)
      this.noteService.trashNote('notes/trash/'+items.id).subscribe(
  
        (response: any) => {
          
            this.snackBar.open(
              "Note untrash",
              "undo",
              { duration: 2500 }
            )
            window.location.reload();
  
          },
          (error: any) =>
          {
            this.snackBar.open(
              "Notes untrash failed",
              "undo",
            )
            }
       
      )
    }

}
