import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pinned',
  templateUrl: './pinned.component.html',
  styleUrls: ['./pinned.component.scss']
})
export class PinnedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
