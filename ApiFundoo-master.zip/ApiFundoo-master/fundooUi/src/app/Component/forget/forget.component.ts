import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/userService/user.service';
import { stringify } from 'querystring';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.scss']
})
export class ForgetComponent implements OnInit {
  forgetForm: FormGroup;
  emails: string;
 

  constructor(private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private router: Router,
    private userService: UserService) { }
  ngOnInit() {

    this.forgetForm = new FormGroup({

      email: new FormControl('', [Validators.required, Validators.email])
      

    });
  }




  forget() {
    
    try {
       this.emails=this.forgetForm .controls.email.value;


      const data = {
        "email": this.forgetForm .controls.email.value
    
      };
      this.userService.forget(this.emails).subscribe((user) => {
        console.log("data-->", user);
        this.snackBar.open('Link sent at your EmailId Successfully!', 'Ok', { duration: 3000 });

      }, (error: any) => {
        console.log(error);
        this.snackBar.open('Email/Password Mismatch!', 'Ok', { duration: 3000 });
        //  this.snackBar.open(error.error.description, 'error', { duration: 3000 });
      });

    }
    catch (err) {
      console.log("err in registeration", err)
    }
  }





}
