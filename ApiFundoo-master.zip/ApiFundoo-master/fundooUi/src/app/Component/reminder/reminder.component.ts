import { Component, OnInit } from '@angular/core';
import { Note } from 'src/app/note';
import { MatSnackBar } from '@angular/material';
import { NoteService } from 'src/app/service/note/note.service';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.scss']
})
export class ReminderComponent implements OnInit {
  note: Note = new Note();
  date: Date = new Date();
  notes : any[]=[];
  sample:any;
  constructor( private snackBar: MatSnackBar,
    private noteService: NoteService) { }
    ngOnInit() {
      this.getAllRemainderNotes()
    }
    getAllRemainderNotes() {
      this.noteService.getAllReminderNotes('notes/reminders').subscribe(
        (response: any) => {
          this.notes = response;
          console.log(this.notes)
         // this.notes = response.result
          // var sample=response.data
          //   console.log("Notes are:",sample);
          // sample.forEach(element=>{
          //   this.notes.push(element);
          // })
          console.log("Array",this.notes);
        }
      )
    }
    

}
