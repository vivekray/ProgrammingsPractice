import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotePropertyComponent } from './note-property.component';

describe('NotePropertyComponent', () => {
  let component: NotePropertyComponent;
  let fixture: ComponentFixture<NotePropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotePropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotePropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
