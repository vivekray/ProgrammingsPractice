import { Component, OnInit } from '@angular/core';
import { NoteComponent } from '../note/note.component';

@Component({
  selector: 'app-note-property',
  templateUrl: './note-property.component.html',
  styleUrls: ['./note-property.component.scss']
})
export class NotePropertyComponent implements OnInit {
     close:boolean=true;
  constructor( ) {
   }

  ngOnInit() {
  }

 

}
