import { Component, OnInit } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { Note } from 'src/app/note';
import { NoteService } from 'src/app/service/note/note.service';
import { DialogBoxComponent } from '../dialog-box/dialog-box.component';

@Component({
  selector: 'app-archieved',
  templateUrl: './archieved.component.html',
  styleUrls: ['./archieved.component.scss']
})
export class ArchievedComponent implements OnInit {

  constructor(private snackBar: MatSnackBar, 
    private noteService: NoteService,
    public matDialog : MatDialog) { }
    note : Note = new Note();
    archive : boolean
    notes : any[]=[];
    sample:any;
    trash:boolean;
    archived:string;

  ngOnInit() {
    this.getAllArchiveNotes();
  }
  getAllArchiveNotes() {
    this.noteService.getAllArchiveNotes('notes/archives').subscribe(
      (response: any) => 
      {
      console.log(response);
      //this.note = response;
      this.notes = response;
      console.log(this.notes)
     
      console.log("Array",this.notes);
      if(this.notes.length<1){
        this.archived="No Notes Is Archived";
      }
    })
  }

  openDialog(items: any) {
    const dialogRef = this.matDialog.open(DialogBoxComponent, {
      width: '500px', height: '190px',
      data: {
        title: items.title,
        description: items.description,
        note_id: items.note_id
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(`dialog result:${result}`);
    });
  
  }
  

  onPin(items) {
    this.noteService.archiveNote('notes/pin/'+items.id).subscribe(
  
      (response: any) => {
        
          this.snackBar.open(
            "Note is Pinned",
            "null",
            { duration: 2500 }
          )
          window.location.reload();
        },
        (error: any) =>
        {
          this.snackBar.open(
            "Notes Pinned failed",
            "undo",
          )
          }
    )
  }


  onArchive(items) {
    this.noteService.archiveNote('notes/archieve/'+items.id).subscribe(
  
      (response: any) => {
        
          this.snackBar.open(
            "Note is Archived",
            "null",
            { duration: 2500 }
          )
          window.location.reload();
        },
        (error: any) =>
        {
          this.snackBar.open(
            "Notes unarchived failed",
            "undo",
          )
          }
    )
  }
  

  colorCodes =
  [
    [
      { name: "white", hexcode: "#ffffff" },
      { name: "lightGreen", hexcode: "#ccff8f" },
      { name: "purple", hexcode: "#d8aefb" },
      { name: "red", hexcode: "#f28b82" },
    ],
    [
      { name: "Teal", hexcode: "#a7feeb" },
      { name: "pink", hexcode: "#fdcfe8" },
      { name: "orange", hexcode: "#fbbd03" },
      { name: "blue", hexcode: "#cbf0f8" },
    ],
    [
      { name: "brown", hexcode: "#e6c9a8" },
      { name: "yellow", hexcode: "#fff474" },
      { name: "darkBlue", hexcode: "#aecbfa" },
      { name: "gray", hexcode: "#e8eaed" }
    ]
  ]

    

    changeColor(color, items) {
      var data = {
        "color": color,
        "_id": items._id
      }
      console.log("color",color)
  
      this.noteService.postColor(data,'/notes/'+data._id+'/color').subscribe(
        (response: any) => {
          console.log(response);
         
          this.getAllArchiveNotes();
          this.snackBar.open(
            'note color updated Successfully..', 
            'End now', 
            { duration: 1000 });
  
        },
        error => {
          console.log(error);
          this.snackBar.open(
            'note color not updated', 
            'End now', 
            { duration: 1000 });
        })
    }
    trashNote(items) {
 
      console.log("TRASHNOTE noteId :::::::",items.id)
      this.noteService.trashNote('notes/trash/'+items.id).subscribe(
    
        (response: any) => {
          
            this.snackBar.open(
              "Note Trashed",
              "null",
              { duration: 2500 }
            )
            window.location.reload();
          },
          (error: any) =>
          {
            this.snackBar.open(
              "Notes untrash failed",
              "undo",
            )
            }
       
      )
    }

}
