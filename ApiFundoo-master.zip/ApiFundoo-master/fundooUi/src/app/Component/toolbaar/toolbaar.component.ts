import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toolbaar',
  templateUrl: './toolbaar.component.html',
  styleUrls: ['./toolbaar.component.scss']
})
export class ToolbaarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
