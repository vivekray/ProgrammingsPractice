import { Component, OnInit,Inject, Input } from '@angular/core';

import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NoteService } from 'src/app/service/note/note.service';


@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.scss']
})
export class DialogBoxComponent implements OnInit {
  @Input() noteData: any
     pin:boolean=false;
     trash:boolean=false;
     archive:boolean=false;
     color:string='white';
  constructor(private snackBar: MatSnackBar,
        public dialogBox: MatDialog,
        private noteService: NoteService,
        @Inject(MAT_DIALOG_DATA) public data: any
        ) { }
   
   title = new FormControl(this.data.title);
  description = new FormControl(this.data.description);
  id = this.data.id

  ngOnInit() {
  }

  colorCodes =
  [
    [
      { name: "white", hexcode: "#ffffff" },
      { name: "lightGreen", hexcode: "#ccff8f" },
      { name: "purple", hexcode: "#d8aefb" },
      { name: "red", hexcode: "#f28b82" },
    ],
    [
      { name: "Teal", hexcode: "#a7feeb" },
      { name: "pink", hexcode: "#fdcfe8" },
      { name: "orange", hexcode: "#fbbd03" },
      { name: "blue", hexcode: "#cbf0f8" },
    ],
    [
      { name: "brown", hexcode: "#e6c9a8" },
      { name: "yellow", hexcode: "#fff474" },
      { name: "darkBlue", hexcode: "#aecbfa" },
      { name: "gray", hexcode: "#e8eaed" }
    ]
  ]
changeColor(color, items) {
  
    this.color=color;
  }


    onPin(){
      this.pin=true;
    }
    onArchive(){
      this.archive=true;
    }
    onTrash(){
     this.trash=true;
    }
  

  onClose() {
    this.dialogBox.closeAll();
    var data1 = {
      "id": this.id,
      "title": this.title.value,
      "description": this.description.value,
      "isPinned":this.pin,
      "isArchived":this.archive,
      "isTrashed":this.trash,
      "color":this.color,
    }

    this.noteService.updateNote('notes/update/' + data1.id,data1).subscribe(
      (res: any) => {
        this.snackBar.open(
          "Notes are updated successfully",
          "undo",
          { duration: 2500 }
        )
        window.location.reload();
      },
      (err) => {
        this.snackBar.open(
          "Notes not updated",
          "undo",
          { duration: 2500 }
        )
      }
    )
  }
}


