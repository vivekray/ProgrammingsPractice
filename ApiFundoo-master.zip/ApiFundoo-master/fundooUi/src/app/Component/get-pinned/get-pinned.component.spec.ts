import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetPinnedComponent } from './get-pinned.component';

describe('GetPinnedComponent', () => {
  let component: GetPinnedComponent;
  let fixture: ComponentFixture<GetPinnedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetPinnedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetPinnedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
