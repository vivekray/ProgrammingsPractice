import { Component, OnInit } from '@angular/core';
import { MatSnackBar, MatDialog } from '@angular/material';
import { NoteService } from 'src/app/service/note/note.service';
import { Note } from 'src/app/note';

@Component({
  selector: 'app-get-pinned',
  templateUrl: './get-pinned.component.html',
  styleUrls: ['./get-pinned.component.scss']
})
export class GetPinnedComponent implements OnInit {

  
  constructor(private snackBar: MatSnackBar, 
    private noteService: NoteService,
    public matDialog : MatDialog) { }
    note : Note = new Note();
    archive : boolean
    notes : any[]=[];
    sample:any;
    trash:boolean
    pinned:string;
    other:string ;

  ngOnInit() {
    this.getAllPinnedNotes();
  }
  getAllPinnedNotes() {
    this.noteService.getAllPinnedNotes('notes/pinned').subscribe(
      (response: any) => 
      {
      console.log(response);
      //this.note = response;
      this.notes = response;
      if(this.notes.length>0){
        this.pinned="PINNED";
        this.other="OTHERS";
       
      }
      else{
        this.pinned=" ";
        this.other=" ";
      }
      console.log(this.notes)
     
      console.log("Array",this.notes);
    })
  }
  

  onPin(items) {
    this.noteService.archiveNote('notes/pin/'+items.id).subscribe(
  
      (response: any) => {
        
          this.snackBar.open(
            "Note is Pinned",
            "null",
            { duration: 2500 }
          )
          window.location.reload();
        },
        (error: any) =>
        {
          this.snackBar.open(
            "Notes Pinned failed",
            "undo",
          )
          }
    )
  }


  onArchive(items) {
    this.noteService.archiveNote('notes/archieve/'+items.id).subscribe(
  
      (response: any) => {
        
          this.snackBar.open(
            "Note is Archived",
            "null",
            { duration: 2500 }
          )
          window.location.reload();
        },
        (error: any) =>
        {
          this.snackBar.open(
            "Notes unarchived failed",
            "undo",
          )
          }
    )
  }
  

  colorCodes =
  [
    [
      { name: "white", hexcode: "#ffffff" },
      { name: "lightGreen", hexcode: "#ccff8f" },
      { name: "purple", hexcode: "#d8aefb" },
      { name: "red", hexcode: "#f28b82" },
    ],
    [
      { name: "Teal", hexcode: "#a7feeb" },
      { name: "pink", hexcode: "#fdcfe8" },
      { name: "orange", hexcode: "#fbbd03" },
      { name: "blue", hexcode: "#cbf0f8" },
    ],
    [
      { name: "brown", hexcode: "#e6c9a8" },
      { name: "yellow", hexcode: "#fff474" },
      { name: "darkBlue", hexcode: "#aecbfa" },
      { name: "gray", hexcode: "#e8eaed" }
    ]
  ]

    

    changeColor(color, items) {
      var data = {
        "color": color,
        "_id": items._id
      }
      console.log("color",color)
  
      this.noteService.postColor(data,'/notes/'+data._id+'/color').subscribe(
        (response: any) => {
          console.log(response);
         
          this.getAllPinnedNotes();
          this.snackBar.open(
            'note color updated Successfully..', 
            'End now', 
            { duration: 1000 });
  
        },
        error => {
          console.log(error);
          this.snackBar.open(
            'note color not updated', 
            'End now', 
            { duration: 1000 });
        })
    }
    trashNote(items) {
 
      console.log("TRASHNOTE noteId :::::::",items.id)
      this.noteService.trashNote('notes/trash/'+items.id).subscribe(
    
        (response: any) => {
          
            this.snackBar.open(
              "Note Trashed",
              "null",
              { duration: 2500 }
            )
            window.location.reload();
          },
          (error: any) =>
          {
            this.snackBar.open(
              "Notes untrash failed",
              "undo",
            )
            }
       
      )
    }

}


