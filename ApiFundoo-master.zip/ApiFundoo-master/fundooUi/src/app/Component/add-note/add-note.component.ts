import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import { NoteService } from '../../services/note/note.service';
//import { Note } from '../../note';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Note } from 'src/app/note';
import { NoteService } from 'src/app/service/note/note.service';
@Component({
  selector: 'app-add-note',
  templateUrl: './add-note.component.html',
  styleUrls: ['./add-note.component.scss']
})
export class AddNoteComponent implements OnInit {
  
  token=localStorage.getItem('FundooToken');
  private popup: boolean;
  constructor(private snackBar: MatSnackBar,
   private noteService: NoteService) { }
    note : Note = new Note();
    
    ngOnInit(): void {
     
    } 
  
  addNote()
  {
    console.log('tokens rrrr',this.token);
    this.popup = false;
    if (this.note.title != null) {
      
      this.noteService.createNote( this.note,'notes/create').subscribe(
      (response: any) => {
        console.log("response",response);
        
        this.note=new Note();
        window.location.reload();
      
         
      },
      (error)=>{

      }
    )
    }
  }

  onPopup() {

    this.popup = true;                           
  }

}
