import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/service/userService/user.service';
import { HttpParams, HttpHeaders, HttpHeaderResponse } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  

  token=localStorage.getItem('tokens')
   header={
    token:this.token
    }
    tockens:string
  loginForm: FormGroup;
  userid:string;

  constructor(private formBuilder:FormBuilder,
    private snackBar:MatSnackBar, 
    private router:Router,private route: ActivatedRoute, 
    private userService: UserService) { }

  ngOnInit() {
    this.tockens =new HttpHeaders().get('tokens');
       // this.userid = this.route.snapshot.paramMap.get("tokens")
   // this.loginForm = this.formBuilder.group({
    this.loginForm = new FormGroup({
     
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      
    });
  }

  login(){
    try{   
         
        const data = {
          "email" : this.loginForm.controls.email.value,
          "password" : this.loginForm.controls.password.value
        };
        this.userService.login(data).subscribe((user) => {
          localStorage.setItem("FundooToken",user.data)
          console.log("data-->", user);
          let confirm=this.snackBar.open('Login Successfully!',' ', { duration: 3000 }) 
         // confirm.onAction().subscribe(() => {
          //  console.log("token==",user.data)
           this.router.navigate(['./dashboard']);
          

        },
         (error: any) => {
          console.log(error);
          this.snackBar.open('Email/Password Mismatch!', 'Ok', { duration: 3000 });
        //  this.snackBar.open(error.error.description, 'error', { duration: 3000 });
        });

    }
    catch(err){
      console.log("err in registeration",err)
    }
  }

}
