import { Component, OnInit, Input, Inject } from '@angular/core';
import { Collaborate } from 'src/app/Model/collaborate';
import { MatSnackBar, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { CollaborateService } from 'src/app/service/collaborate/collaborate.service';

@Component({
  selector: 'app-collabarator',
  templateUrl: './collabarator.component.html',
  styleUrls: ['./collabarator.component.scss']
})
export class CollabaratorComponent implements OnInit {
  @Input() noteData: any
  colabs: any[];
  colab: Collaborate = new Collaborate();
  constructor(private snackbar: MatSnackBar,
    private collabService: CollaborateService,
    public dialogBox: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    //id = this.data.note_id;
  ngOnInit() {
    this.getAllPinnedNotes();
  }
  
    
  
  getAllPinnedNotes() {



    const data1={
      "noteid":this.data.id,
    }
    this.collabService.getCollab('collaborator/fetchColab/'+this.data.id).subscribe(
      (response: any) => 
      {
      console.log(response);
      this.colabs = response;
      // if(this.notes.length>0){
      //   this.pinned="PINNED";
      //   this.other="OTHERS";
       
      // }
      // else{
      //   this.pinned=" ";
      //   this.other=" ";
      // }
      console.log(this.colabs)
     
      console.log("Array",this.colabs);
    })
  }
  
  addCollab() {
       const data1={
         "noteid":this.data.id,
         "emailid":this.colab.emailid
       }
       console.log("response --------------", data1);
    this.collabService. collaborate(data1,'collaborator/addCollab').subscribe(
      (response: any) => {
        console.log("response --------------", response);
        this.snackbar.open(
          "Label created Successfully",
          "undo",
          { duration: 2500 }
        )
      },
      (error) => {

        this.snackbar.open(
          "Label creation Failed",
          "undo",
          { duration: 2500 }
        )
      }
    )
  }


  removeCollab(email:string) {
    const data1={
      "noteid":this.data.id,
      "emailid":email,
    }
    console.log("emails"+data1.emailid)
    console.log("response --------------", data1);
 this.collabService. deleteCollab('collaborator/removeCollab/'+data1.noteid+'/'+data1.emailid).subscribe(
   (response: any) => {
     console.log("response --------------", response);
     this.snackbar.open(
       "Label created Successfully",
       "undo",
       { duration: 2500 }
     )
   },
   (error) => {

     this.snackbar.open(
       "Label creation Failed",
       "undo",
       { duration: 2500 }
     )
   }
 )
}


}
