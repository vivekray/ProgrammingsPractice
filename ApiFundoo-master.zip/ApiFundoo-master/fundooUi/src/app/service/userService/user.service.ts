import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient , HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  private API_URL = environment.apiUrl; 

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) {
  }
  registration(user: any): Observable<any> {
    console.log(user);
    return this.http.post<any>(this.API_URL + 'users/register', user, this.httpOptions);
    //return this.http.post(this.baseUrl + options.url, options.data);
  }

 

  login(user: any): Observable<any> {

    console.log(user);
    return this.http.post<any>(this.API_URL + 'users/login', user, this.httpOptions);
  }


   forget(user:string): Observable<string> {
    let params = new HttpParams()
     .set('email', user)
      console.log(user);
     return this.http.get<string>(this.API_URL+'users/forget', {params});
     
    //return this.http.get<any>(this.API_URL+'users/forget',{headers:new HttpHeaders().set('email',localStorage.getItem('email'))});
   }

   reset(user:any,token:string): Observable<any> {
     //let tocken=new HttpParams().get('token')
     let params = new HttpParams()
     .set('token', token)
     console.log(user);
     console.log(token);
     
     
     return this.http.post<any>(this.API_URL+'users/reset',user,{params});
    
   }




}
