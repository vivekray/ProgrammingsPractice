import { Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';

@Injectable({
  providedIn: 'root'
})
export class CollaborateService {
  constructor(private httpService: HttpService) { }
  collaborate(data,url)
  {
    var option = 
    {
      
      url : url,
      data : data
    }
    console.log("url",option.url)
    return this.httpService.post(option);
  }
  getCollab(url){
   
    var option = 
    {
      url : url,
    }
    return this.httpService.get(option)
  

  }




  deleteCollab(url){
    var option={
      url:url,
    }
    return this.httpService.delete(option);

  }




}
