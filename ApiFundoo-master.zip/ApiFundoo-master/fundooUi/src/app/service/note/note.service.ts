import { Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';


@Injectable({
  providedIn: 'root'
})
export class NoteService {

  constructor(private httpService: HttpService) { }
  createNote(data, url)
    {
      var option = 
      {
        
        url : url,
        data : data
      }
      console.log("url",option.url)
      return this.httpService.post(option);
    }
    getAllTrashedNotes(url){
      var option={
        url:url
        
      }
      return this.httpService.get(option);

    }
    archiveNote(url){
      var option = 
      {
        
        url : url,
        data : null
      }
      
      return this.httpService.post(option);
  }

    trashNote(url){
      var option = 
      {
        
        url : url,
        data:null
      }
      console.log("url",option.url)
      return this.httpService.post(option);

    }
    deleteNote(url){
      var option={
        url:url
      }
      return this.httpService.delete(option);

    }
    updateNote(url,data){
    var option = 
    {
      
      url : url,
      data : data
    }
    console.log("url",option.url)
    return this.httpService.post(option);
    
  }
  getAllArchiveNotes(url){
    var option=
      {
        url:url
      }
      return this.httpService.get(option);
    
  }
  getAllPinnedNotes(url){
    var option=
      {
        url:url
      }
      return this.httpService.get(option);
  }
  
postColor(data,url){
  var option={
    url:url,
    data:data
  }
  return this.httpService.post(option)
}
getAllNotes(url){
  var option=
  {
    url:url
  }
  return this.httpService.get(option);

}
getAllReminderNotes(url){
  var option=
  {
    url:url
  }
  return this.httpService.get(option);

}
setReminder(data,url)
  {
    var option = 
    {
      url : url,
      data : data
    }
    return this.httpService.post(option)
  }
  deleteReminder(url){
    var option = 
    {
      url : url,
      data : {remainder:null}
    }
    return this.httpService.post(option)
  }

}
