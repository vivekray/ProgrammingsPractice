//package com.fundoo.tests;
//
//import javax.xml.ws.Response;
//
//import org.junit.Assert;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.MvcResult;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//
//import com.bridgelabz.fundoo.controller.UserController;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest
//class FirstMockitoTest {
//	private MockMvc mockMvc;
//	ObjectMapper om=new ObjectMapper();
//	
//	
//	//@InjectMocks
//	//@Autowired
//    UserController userController=new  UserController();
//	
//	
//	
//
////	@Mock
////	private UserDAO userDao;
//	
////	//@InjectMocks
////	private UserService userService;
////   
//    
//	
//	
//	@BeforeEach
//	public void setup() throws Exception {
//		//MockitoAnnotations.initMocks(this);
//		mockMvc=MockMvcBuilders.standaloneSetup(userController).build();
//		
//	}
//	
//	@Test
//	public void testGetUser() throws Exception {
//		
//		
//	MvcResult result=	mockMvc.perform(MockMvcRequestBuilders.get("/users/list").content(MediaType.APPLICATION_JSON_VALUE))
//			.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
//	String resultContent=result.getResponse().getContentAsString();
//	Response res=om.readValue(resultContent,Response.class);
//	Assert.assertTrue(res.isDone());
//     
//	
//			
//			
//				
//		        // .andExpect(MockMvcResultMatchers.content().string("hel);
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		//UserDto userDto = new UserDto();
//		
////		System.out.println(userServiceImpl.getUserById(1L, "Hello ray"));
////		userDto.setFirstName("Vivek");
////		userDto.setLastName("Ray");
////		userDto.setEmail("vivekray0@gmail.com");
////		userDto.setPassword("**************");
////		userDto.setMobileNumber(987381207L);
//		///Long id=1L;
//	//	userDto=userService.getUserById(id, "hello");
//		//System.out.println("Hello"+userDto);
//	//when(userDto).thenReturn((users));
//		//verify(users).
//		//System.out.println("**--- UserCreated ---**");
//		//UserDto users=userService.getUserById(1L, "error");
//
//		
//		
//
//		//assertEquals(userDto,userService.getUserById(1L, "error"));
//
//	}
//
//
//    //
////	
////	@Test
////	void test() {
////		assertTrue(true);
////	}
//
//}
