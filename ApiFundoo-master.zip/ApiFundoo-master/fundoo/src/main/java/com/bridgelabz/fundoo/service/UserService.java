package com.bridgelabz.fundoo.service;

import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import com.bridgelabz.fundoo.dto.ResetPasswords;
import com.bridgelabz.fundoo.dto.UserDto;

public interface UserService {
	

	List<UserDto> getAllUser();
	
	UserDto getUserById(Long userId);
	
	UserDto saveUser(UserDto user) throws MessagingException;
	
	int deleteUser(Long userId);
   
	boolean verifyUser(String fromGeneratedToken);
	
	void sendEmail(String url,String toEmail, String generatedToken) throws MessagingException ;
	 
	String loginUser(UserDto userDto);
	 
	public boolean isUserPresent(String email);
	
	boolean forgotPassword(String emailId) throws MessagingException;
	 
	public int updateUser(String generatedtoken, ResetPasswords passwordReset);
	 
	Map<String,String> validation(UserDto user);
	
	int isVarify(String email);

}
