package com.bridgelabz.fundoo.repo;

import java.time.LocalDateTime;
import java.util.List;

import com.bridgelabz.fundoo.dto.ResetPasswords;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.model.User;

public interface NotesDAO {
	public List<Note> getAllNote(Long userid);
	public List<Note> getTrashedNote(Long userid);
	public List<Note> getArchiveNote(Long userid);
	public List<Note> getPinnedNote(Long userid) ;
	public List<Note> getReminder(Long userId);

	Note getNoteById(Long userId);
	int createNote(Note notes);
    Note save(Note noterInformation);
	int deleteNote(Long userId);
	int updateNote(Note e);
	int archievNote(Long id,Long token);
	int trashNote(Long id,Long token);
	int pin(long id, Long token);
	int reminder(Long id,String token,LocalDateTime reminder);
	    
}
