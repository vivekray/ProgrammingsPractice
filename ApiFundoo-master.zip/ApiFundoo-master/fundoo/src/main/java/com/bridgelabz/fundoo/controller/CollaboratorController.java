package com.bridgelabz.fundoo.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.exceptions.JWTVerificationException;
import com.bridgelabz.fundoo.dto.CollabDto;
import com.bridgelabz.fundoo.model.Collaborator;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.response.Response;
import com.bridgelabz.fundoo.service.CollaboratorService;

@CrossOrigin(origins = "*", exposedHeaders = { "token" })
@RestController
@RequestMapping("/collaborator")
public class CollaboratorController {
	@Autowired
	private CollaboratorService service;
	
	@PostMapping("/addCollab")
	public ResponseEntity<Response> addCollaborator(@RequestBody CollabDto collabDto,
			@RequestHeader("token") String token) {
		System.out.println(collabDto);
		
		int s=service.addCollaborator(collabDto.getNoteid(), collabDto.getEmailid(), token);
		//System.out.println(note.getCollabList().toString());
		
	

		return ResponseEntity.status(HttpStatus.CREATED).body(new Response(200,"collaborator added", s));

	}
	@GetMapping("/fetchColabNote")
	public ResponseEntity<Response> getAllNotes(@RequestHeader("token") String token) throws JWTVerificationException, IllegalArgumentException, UnsupportedEncodingException {

		//List<Note> notes = service.getColabNotes(token);
//System.out.println(notes);
		return ResponseEntity.status(HttpStatus.OK).body(new Response(200,"reqired notes are",  null));
	}
	@GetMapping("/fetchColab/{noteid}")
	public List<Collaborator> getAllCollab(@RequestHeader("token") String token,@PathVariable("noteid")Long noteid){

		System.out.println(token);
		
		return service. getColab(token,noteid);

		//return ResponseEntity.status(HttpStatus.OK).body(new Response(200,"reqired notes are",  null));
	}

	@DeleteMapping("/removeCollab/{noteid}/{emailid}")
	public ResponseEntity<Response> removeCollaborator(@PathVariable("noteid")Long noteid,@PathVariable("emailid")String emailid,
			@RequestHeader("token") String token) {
		int s=service.removeCollaborator(noteid,emailid, token);
		//System.out.println(noteId);
		//Note note=service.removeCollaborator(noteId, email, token);
		//System.out.println(note.getCollabList().toString());
	

		return ResponseEntity.status(HttpStatus.CREATED).body(new Response(200,"collaborator removed",  null));

	}

}

