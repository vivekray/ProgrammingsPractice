package com.bridgelabz.fundoo.response;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class Response implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer status;

	private String message;

	private Object data;

	public Response(Integer status, String message) {
		this.status = status;
		this.message = message;
	}

	public Response(Integer status, String message, Object data) {
		this.status = status;
		this.message = message;
		this.data = data;

	}
}
