package com.bridgelabz.fundoo.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;

import com.bridgelabz.fundoo.dto.UserDto;

@PropertySource("classpath:messages.properties")
public class Validations {
	private UserDto user;

//	@Value("${first_name}")
//	private String first_name;
//
//	@Value("${last_name}")
//	private String last_name;
//
//	@Value("${email_id}")
//	private String email_id;
//
//	@Value("${mobile_number}")
//	private Integer mobile_number;
//
//	@Value("${password}")
//	private String password;

	public Validations() {
		user = new UserDto();
	}

	public static Map<String, String> isValidFields(UserDto user) {
		Map<String, String> errorMessages = new HashMap<String, String>();
		List<Boolean> list = new ArrayList<Boolean>();

		String[] fields = { "FirstName", "LastName", "Email-Id", "MobileNumber", "Password" };
		String PASSWORD_PATTERN = "^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$";

		String[] status = { "Invalid FirstName", "Invalid LastName", "Invalid Email-Id", "Invalid Number",
				"Password Should bemix of Alphabet,Symbol and Number with Mainimum 8 disgts" };
		String result = "Ok";

		list.add(Pattern.matches("[a-zA-Z]{1,10}", user.getFirstName()));
		list.add(Pattern.matches("[a-zA-Z]{1,10}", user.getLastName()));
		list.add(Pattern.matches("^(.+)@(.+)$", user.getEmail()));
		list.add(Pattern.matches("[789]{1}[0-9]{9}", user.getMobileNumber().toString()));
		list.add(Pattern.matches(PASSWORD_PATTERN, user.getPassword()));

		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) == false) {
				result = status[i];
				errorMessages.put(fields[i], status[i]);

				// break;
			}

		}

		return errorMessages;
	}

}
