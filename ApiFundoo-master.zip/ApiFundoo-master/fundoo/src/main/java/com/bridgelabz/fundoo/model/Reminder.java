package com.bridgelabz.fundoo.model;

import java.time.LocalDateTime;

import org.joda.time.format.DateTimeFormatter;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Reminder {
	
	 //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "E, MMM dd yyyy HH:mm:ss")
	
	private String reminder;
}
