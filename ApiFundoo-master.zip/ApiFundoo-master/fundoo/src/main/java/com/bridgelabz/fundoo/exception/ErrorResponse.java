package com.bridgelabz.fundoo.exception;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bridgelabz.fundoo.response.Response;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Data
public class ErrorResponse{

	private Integer status;
	
	//private   Map<String, Object> details;
	List<String> details;
	

	public ErrorResponse(int status, List<String> details) {
	 //super(status,details);
		this.status = status;
		this.details=details;
		
		
	}
	
}
