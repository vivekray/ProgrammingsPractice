package com.bridgelabz.fundoo.service;

import java.time.LocalDateTime;
import java.util.List;

import com.bridgelabz.fundoo.dto.NotesDto;
import com.bridgelabz.fundoo.dto.UserDto;
import com.bridgelabz.fundoo.model.NoteUpdation;

public interface NoteService {
    List<NotesDto> getAllNote(String token);
    List<NotesDto> getTrashedNotes(String token);
	List<NotesDto> getArchiveNote(String token);
	List<NotesDto> searchByTitle(String title);
    List<NotesDto> getAllPinnedNotes(String token);
    List<NotesDto> getAllReminders(String token);
	NotesDto getNoteById(Long userId,String error);
	NotesDto createNote(NotesDto notes,String token);
	int deleteNote(Long userId);
	public int updateNote();
	
	//////////////////////////////////////////////////////////////////////////

	void updateNote(NoteUpdation information, String token);

	

	boolean deleteNotePemenetly(long id, String token);

	void archievNote(long id, String token);
	
	void trashNote(Long id, String token); 
	
	void pin(long id, String token);

	

	void addColour(Long noteId, String token, String colour);
	void addReminder(Long noteId,String token,String reminder);
	void removeReminder(Long noteId, String token, String reminder);



	
//	 

	
}
