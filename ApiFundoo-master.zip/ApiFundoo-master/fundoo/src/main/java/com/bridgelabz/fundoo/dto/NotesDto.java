package com.bridgelabz.fundoo.dto;

import java.time.LocalDateTime;

import lombok.Data;
@Data
public class NotesDto {
	private Long id;
	
	private String title;
	private String description;
	private boolean isArchieved;
	private boolean isPinned;
	private boolean isTrashed;
	private String color;
	private LocalDateTime reminder;
	
	
//	public Long getId() {
//		return id;
//	}
//	public void setId(Long id) {
//		this.id = id;
//	}
//	
//	public String getTitle() {
//		return title;
//	}
//	public void setTitle(String title) {
//		this.title = title;
//	}
//	public String getDescription() {
//		return description;
//	}
//	public void setDescription(String description) {
//		this.description = description;
//	}
//	public boolean isArchieved() {
//		return isArchieved;
//	}
//	public void setArchieved(boolean isArchieved) {
//		this.isArchieved = isArchieved;
//	}
//	public boolean isPinned() {
//		return isPinned;
//	}
//	public void setPinned(boolean isPinned) {
//		this.isPinned = isPinned;
//	}
//	public boolean isTrashed() {
//		return isTrashed;
//	}
//	public void setTrashed(boolean isTrashed) {
//		this.isTrashed = isTrashed;
//	}
//	public String getColour() {
//		return colour;
//	}
//	public void setColour(String colour) {
//		this.colour = colour;
//	}
//	public LocalDateTime getReminder() {
//		return reminder;
//	}
//	public void setReminder(LocalDateTime reminder) {
//		this.reminder = reminder;
//	}
//
	

}
