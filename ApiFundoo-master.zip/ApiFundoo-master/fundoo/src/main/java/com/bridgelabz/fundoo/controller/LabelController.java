
package com.bridgelabz.fundoo.controller;

import org.springframework.http.HttpStatus;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bridgelabz.fundoo.dto.LabelDto;
import com.bridgelabz.fundoo.model.Label;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.response.Response;
import com.bridgelabz.fundoo.service.LabelService;

@RestController
@PropertySource("classpath:messages.properties")
@CrossOrigin(allowedHeaders = "*", origins = "*",exposedHeaders= {"jwtTocken"})
@RequestMapping("/label")
//@Validated
public class LabelController {
	
	@Autowired
	private LabelService labelService;

	@PostMapping("/create")
	public ResponseEntity<Response> createLabel(@RequestBody LabelDto label, @RequestHeader("token") String token) {
		System.out.println(label.getName());
		labelService.createLabel(label, token);
		return ResponseEntity.status(HttpStatus.CREATED).body(new Response(200,"label created" ,label));
	}
	
	@PostMapping("/createandmap")
	public ResponseEntity<Response> createLabelAndMap(@RequestBody LabelDto label, @RequestHeader("token") String token,@RequestParam("noteId") Long noteId) {
		System.out.println("label is"+label.getName());
		System.out.println("note id is"+noteId);

		labelService.createLabelAndMap(label, token, noteId);
		return ResponseEntity.status(HttpStatus.CREATED).body(new Response( 200,"label created", label));
	}

	@PostMapping("/addlabel")
	public ResponseEntity<Response> addLabel(@RequestParam("labelId") Long labelId,
			@RequestHeader("token") String token, @RequestParam("noteId") Long noteId) {
		System.out.println(labelId);
		labelService.addLabel(labelId, noteId, token);
		return ResponseEntity.status(HttpStatus.OK).body(new Response( 200,"label added to"));

	}
	
	@PostMapping("/removelabel")
	public ResponseEntity<Response> removeLabel(@RequestParam("labelId") Long labelId,
			@RequestHeader("token") String token, @RequestParam("noteId") Long noteId) {
		System.out.println(labelId);
		labelService.removeLabel(labelId, noteId, token);
		return ResponseEntity.status(HttpStatus.OK).body(new Response(200,"label removed to"));

	}
	
	

	@GetMapping("/getAllLabel")
	public ResponseEntity<Response> get(@RequestHeader("token") String token) {
		List<Label> labels = labelService.getLabel(token);
		return ResponseEntity.status(HttpStatus.OK).body(new Response(200,"reqired labels are", labels));

	}

	@GetMapping("/getLabelNotes")
	public ResponseEntity<Response> getNotes(@RequestHeader("token") String token,@RequestParam("id") Long labelId) {
	List<Note> list=labelService.getAllNotes(token, labelId);
		
	return ResponseEntity.status(HttpStatus.OK).body(new Response(200,"reqired notes are", list));

	}

	
	
}
