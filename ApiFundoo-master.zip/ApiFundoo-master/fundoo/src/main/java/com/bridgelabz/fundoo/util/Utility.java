package com.bridgelabz.fundoo.util;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import com.bridgelabz.fundoo.dto.NotesDto;
import com.bridgelabz.fundoo.dto.UserDto;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.model.User;

public class Utility {
/////UserDto To User
	public static User userDtoToEntity(UserDto userDto) {
		if(userDto!=null) {
		User user = new User();
       user.setFirstName(userDto.getFirstName());
		user.setLastName(userDto.getLastName());
		user.setEmail(userDto.getEmail());
		user.setPassword(userDto.getPassword());
		user.setMobileNumber(userDto.getMobileNumber());
		user.setIsVarify("false");
		LocalDateTime date=LocalDateTime.now();
		user.setCreatedTime(date);
		user.setUpdatedTime(date);
//		NotesInformations ob=new NotesInformations();
//	     ob.setTitle("hello");
//	     NotesInformations ob1=new NotesInformations();
//	     ob1.setTitle("hello2");
//	     List<NotesInformations> list = null;
//	     list.add(ob);
//	     list.add(ob1);
//	     user.setNote(list);

		return user;
		}
		else
		{
			return null;
		}
	}

	
/////User To UserDto
	@SuppressWarnings("static-access")
	public static UserDto entityToUserDto(User user) {
		if(user!=null) {
		UserDto userDto = new UserDto();
		userDto.setFirstName(user.getFirstName());
		userDto.setLastName(user.getLastName());
		userDto.setEmail(user.getEmail());
		userDto.setPassword("**************");
		userDto.setMobileNumber(user.getMobileNumber());
		userDto.setCreatedTime(user.getCreatedTime());
		userDto.setUpdatedTime(user.getUpdatedTime());
		return userDto;
		}
		else {
			return null;
		
		}
	}
	////////////List User To UserDto
	 public static List<UserDto>  userDtoConvertList(List<User> userList) {
		 List<UserDto> list=new LinkedList<UserDto>();
		 for(User user:userList)
			list.add(entityToUserDto(user));
		 
		return (List<UserDto>)list;
	 }
////////////List UserDto To User
	 public static List<User>  userConvertList(List<UserDto> userDtoList) {
		 List<User> list=new LinkedList<User>();
		 for(UserDto userDto:userDtoList)
			list.add(userDtoToEntity(userDto));
		 
		return list;
	 }
	 
	 
	/////NotesDto To Notes
	 
	 
	 public static Note noteDtoToNote(NotesDto noteDto) {
		 if(noteDto!=null) {
		 Note note=new Note();
		 note.setTitle(noteDto.getTitle());
		 note.setDescription(noteDto.getDescription());
		 note.setPinned(false);
		 note.setArchieved(false);
		 note.setColor(noteDto.getColor());
		 note.setReminder(noteDto.getReminder());
		 note.setTrashed(false);
		 LocalDateTime date=LocalDateTime.now();
		 
	     note.setCreatedDateAndTime(date);
	     note.setUpDateAndTime(date);
	     note.setUserid(4L);
		 return note; 
		 }
		 else {
			 return null;
		 }
	 }
	
	 
	 /////Notes To NotesDto
	 public static NotesDto noteToNotesDto(Note notes) {
		 if(notes!=null) {
		 NotesDto noteDto=new NotesDto();
		 noteDto.setId(notes.getNoteId());
		 noteDto.setTitle(notes.getTitle());
		 noteDto.setDescription(notes.getDescription());
		 noteDto.setPinned(notes.isPinned());
		 noteDto.setArchieved(notes.isArchieved());
		 noteDto.setColor(notes.getColor());
		 noteDto.setReminder(notes.getReminder());
		 noteDto.setTrashed(notes.isTrashed());
		 return noteDto;
		 }
		 else {
			 return null;
		 }
		  
	 }
	 ///////List NoteDto to Notes
	 public static List<NotesDto>  convertNoteToNotesDto(List<Note> notesList) {
		 List<NotesDto> list=new LinkedList<NotesDto>();
		 for(Note notes:notesList)
			list.add(noteToNotesDto(notes));
		 
		return (List<NotesDto>) list;
	 }
	 
///////List Notes to NotesDto
	 public static List<Note>  convertNotesDtoToNote(List<NotesDto> noteDto) {
		 List<Note> list=new LinkedList<Note>();
		 for(NotesDto notes:noteDto)
			list.add(noteDtoToNote(notes));
		 
		return (List<Note>) list;
	 }
	 
	

	
	
	
	
}
