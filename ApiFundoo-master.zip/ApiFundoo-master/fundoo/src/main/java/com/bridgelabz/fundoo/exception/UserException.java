package com.bridgelabz.fundoo.exception;

import java.util.Map;

public class UserException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	private String message;

	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public UserException(String message) {
		super(message);
		this.message=message;
		// TODO Auto-generated constructor stub
	}
	

}
