package com.bridgelabz.fundoo.model;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class NoteUpdation {
	private Long id;
	private String title;
	private String description;
	private boolean isArchieved;
	private boolean isPinned;
	private boolean isTrashed;
	private String color;
	private LocalDateTime createdDateAndTime;
	private LocalDateTime upDateAndTime;

}