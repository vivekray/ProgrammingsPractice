package com.bridgelabz.fundoo.repo;

import java.util.List;

import com.bridgelabz.fundoo.dto.ResetPasswords;
import com.bridgelabz.fundoo.model.User;

public interface UserDAO {
	
	List<User> getAllUser();
	User getUserById(Long userId);
	User getUserByEmail(String email);
	int saveUser(User user);
	int deleteUser(Long userId);
	boolean isValidUser(String id);
	void changeStatus(Long id);
	boolean userDaoLogin(User user);
	List<User> checkUser(String id);
	int updatePassword(String emailId,ResetPasswords user);
    int isVarify(String id);

}
