package com.bridgelabz.fundoo.controller;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bridgelabz.fundoo.dto.ResetPasswords;
import com.bridgelabz.fundoo.dto.UserDto;
import com.bridgelabz.fundoo.exception.UserException;
import com.bridgelabz.fundoo.response.Response;
import com.bridgelabz.fundoo.service.UserService;
import com.bridgelabz.fundoo.util.GetAllProperties;
////,exposedHeaders = {"jwtToken"}
@RestController
@PropertySource("classpath:messages.properties")
@CrossOrigin(allowedHeaders = "*", origins = "*",exposedHeaders= {"jwtTocken"})
@RequestMapping("/users")
@Validated
public class UserController {
	@Autowired
	private UserService userService;

//	@GetMapping("/{userId}")
//	public ResponseEntity<Response> getUsers(@RequestParam(value = "userId",required =false)Long userId,
//			@Value("${user_not_get}") String error) {
//		    System.out.println(userId);
//		if (userId == null) {
//			return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "GetAllUsers Successfully!", getAllUser()),
//					HttpStatus.OK);
//		} else {
//
//			return new ResponseEntity<>(
//					new Response(HttpStatus.OK.value(), "Found Successfully!", getUserById(userId, error)),
//					HttpStatus.OK);
//		}
//	}

	@GetMapping("/list")

	List<UserDto> getAllUser() {
		return userService.getAllUser();
	}

	@PostMapping(value = "/register")

	public ResponseEntity<Response> saveUser(@Valid @RequestBody UserDto user)
			throws MessagingException {
		return new ResponseEntity<Response>(
				new Response(HttpStatus.OK.value(), "Registerd Successfully!", userService.saveUser(user)),
				HttpStatus.OK);
	}

	 @GetMapping(path = "/get/{userid}")
	public ResponseEntity<Response> getUserById(@PathVariable("userid") Long userId) {
		//GetAllProperties.getProperties();

		UserDto user = userService.getUserById(userId);
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Found Successfully!", user), HttpStatus.OK);

	}

	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<Response> deleteStudentById(@PathVariable Long userId) {

		     userService.deleteUser(userId);

			return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Deleted Successfully!"), HttpStatus.OK);
		
	}

	@GetMapping("/verify/{token}")
	public ResponseEntity<Response> verifyUserByMail(@PathVariable("token") String token) {
		System.out.println("hello in verify");
		if (userService.isVarify(token) > 0) {
		//	if (userService.verifyUser(token,error)) {
			userService.verifyUser(token);
				return new ResponseEntity<>(new Response(HttpStatus.OK.value(), " Varified Successfully!"),
						HttpStatus.OK);
//			} else {
//				throw new UserException(error);
//			}
		} else
			return new ResponseEntity<>(
					new Response(HttpStatus.BAD_REQUEST.value(), "Email is Already Varified, You can Login!"),
					HttpStatus.BAD_REQUEST);
	}

	@PostMapping("/login")
	public ResponseEntity<Response> loginUser(@RequestBody UserDto user) {
		HttpHeaders responseHeaders = new HttpHeaders();
		String tokens=userService.loginUser(user);
		
	   // responseHeaders.set("tokens",tokens.toString());
	    responseHeaders.add("tokens",tokens);
		System.out.println("tokens=="+tokens);
		 
		//////////////////////
		   
			return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Login Successfully!",tokens),responseHeaders, HttpStatus.OK);
//		} else {
//			throw new UserException(error);
//
//		}

	}
//{email}
	@GetMapping("/forget")
	//@PathVariable("email") String email
	public ResponseEntity<Response> forgetPassword(@RequestParam String email) throws MessagingException {
		if (userService.isUserPresent(email)) {
			userService.forgotPassword(email);
			return new ResponseEntity<>(
					new Response(HttpStatus.OK.value(), "Link sent at Your Email " + email + " Successfully!"),
					HttpStatus.OK);
		} else
			throw new UserException("Not find");

	}
//@PathVariable("token")
	@PostMapping("/reset")
	public ResponseEntity<Response> updateUser(@RequestParam String token,
			@RequestBody ResetPasswords resetPass) {
		
		int i=userService.updateUser(token, resetPass);
			return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Password Updated successfully"),
					HttpStatus.OK);
		
	}

	

}