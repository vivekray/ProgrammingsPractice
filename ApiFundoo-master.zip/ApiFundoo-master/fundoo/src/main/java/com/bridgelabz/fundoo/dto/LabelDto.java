package com.bridgelabz.fundoo.dto;

import lombok.Data;

@Data
public class LabelDto {
	private String name;
}
