package com.bridgelabz.fundoo.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bridgelabz.fundoo.dto.NotesDto;
import com.bridgelabz.fundoo.exception.UserException;
import com.bridgelabz.fundoo.model.NoteUpdation;
import com.bridgelabz.fundoo.model.Reminder;
import com.bridgelabz.fundoo.response.Response;
import com.bridgelabz.fundoo.service.NoteService;
import com.bridgelabz.fundoo.util.GetAllProperties;

@RestController
@PropertySource("classpath:messages.properties")
@CrossOrigin(allowedHeaders = "*", origins = "*",exposedHeaders= {"jwtTocken"})
@RequestMapping("/notes")
@Validated
public class NotesController {
	
	@Autowired
	private NoteService noteService;

	@GetMapping("/list")
	List<NotesDto> getAllNote(@RequestHeader String token) {
		return noteService.getAllNote(token);
	}
	
	@GetMapping("/archives")
	List<NotesDto> getAllArchive(@RequestHeader String token) {
		return noteService.getArchiveNote(token);
	}
	
	@GetMapping("/trashed")
	List<NotesDto> getAllTrashed(@RequestHeader String token) {
		return noteService.getTrashedNotes(token);
	}
	
	@GetMapping("/pinned")
	List<NotesDto> getAllPinned(@RequestHeader String token) {
		return noteService.getAllPinnedNotes(token);
	}
	
	@GetMapping("/reminders")
	List<NotesDto> getAllReminder(@RequestHeader String token) {
		return noteService.getAllReminders(token);
	}

	@PostMapping(value = "/create")//@RequestParam @RequestHeader Long token
    public ResponseEntity<Response> saveNote(@RequestHeader String token,@Valid @RequestBody NotesDto notes)
			throws MessagingException {
		    return new ResponseEntity<Response>(
				new Response(HttpStatus.OK.value(), "Created Successfully!", noteService.createNote(notes,token)),
				HttpStatus.OK);
	}

	@GetMapping(path = "/getnote/{noteId}")
	public ResponseEntity<Response> getUserById(@PathVariable Long noteId, @Value("${user_not_get}") String error) {
		GetAllProperties.getProperties();

		NotesDto note = noteService.getNoteById(noteId, error);
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Found Successfully!", note), HttpStatus.OK);

	}
	
	@PostMapping("/update/{noteId}")
	public ResponseEntity<Response> update(@RequestHeader String token,@Valid @RequestBody NoteUpdation notes,
			@PathVariable Long noteId,
			@Value("${user_not_delete}") String error) {
		noteService.updateNote(notes,token);
		 return new ResponseEntity<Response>(
					new Response(HttpStatus.OK.value(), "Created Successfully!", null),
					HttpStatus.OK);

	}
	

	
	
	

	@DeleteMapping("/delete/{noteId}")
	public ResponseEntity<Response> deleteStudentById(@PathVariable Long noteId,
			@Value("${user_not_delete}") String error) {

		if (noteService.deleteNote(noteId) > 0) {

			return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Deleted Successfully!"), HttpStatus.OK);
		} else {
			throw new UserException(error);
		}

	}
	
	
	@PostMapping("/archieve/{id}")
	public ResponseEntity<Response> archieve(@PathVariable String id, @RequestHeader("token") String token) {
		noteService.archievNote(Long.parseLong(id), token);
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Archived Successfully!"), HttpStatus.OK);
	}
	
	@PostMapping("/trash/{id}")
	public ResponseEntity<Response> trash(@PathVariable String id, @RequestHeader("token") String token) {
		noteService.trashNote(Long.parseLong(id), token);
	
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Trashed Successfully!"), HttpStatus.OK);
	}
	

	@PostMapping("/pin/{id}")
	public ResponseEntity<Response> pin(@PathVariable long id, @RequestHeader("token") String token) {

		noteService.pin(id, token);
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Pinned Successfully!"), HttpStatus.OK);

	}
	
	@PostMapping("/color/{id}")
	public ResponseEntity<Response> color(@PathVariable long id, @RequestHeader("token") String token,@RequestBody NotesDto note) {
		System.out.println("COlor=================="+note.getColor());
		noteService.addColour(id, token,note.getColor());
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Color Changed  Successfully!"), HttpStatus.OK);

	}
	@PostMapping("/reminder/{id}")
	public ResponseEntity<Response> reminder(@PathVariable long id, @RequestHeader("token") String token,@RequestBody Reminder reminder) {
        System.out.println("Time reminder=================="+reminder.getReminder());
     
        
        noteService.addReminder(id, token, reminder.getReminder());
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Reminder Added  Successfully!"), HttpStatus.OK);

	}
	@PostMapping("/deletereminder/{id}")
	public ResponseEntity<Response> removeReminder(@PathVariable long id, @RequestHeader("token") String token,@RequestBody Reminder reminder) {
		   noteService.removeReminder(id, token, null);
		return new ResponseEntity<>(new Response(HttpStatus.OK.value(), "Reminder Added  Successfully!"), HttpStatus.OK);

	}
	

}