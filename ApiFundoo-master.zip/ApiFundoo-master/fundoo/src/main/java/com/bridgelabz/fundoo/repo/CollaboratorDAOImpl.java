package com.bridgelabz.fundoo.repo;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.query.Query;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bridgelabz.fundoo.model.Collaborator;
import com.bridgelabz.fundoo.model.Note;
@Repository
public class CollaboratorDAOImpl implements CollaboratorDAO {

	@Autowired
	private UserDAO userdao;
	
	@Autowired
	private EntityManager entityManager;
	@Override
	public int addCollaborator(Collaborator collaborator) {
		    Session session = entityManager.unwrap(Session.class);
			session.saveOrUpdate(collaborator);
			return 1;
	}
	@Override
	public int removeCollaborator(Long noteId, String email, String token) {
//		  Long userid=userdao.checkUser(email)
		Session session = entityManager.unwrap(Session.class);
		Query query=session.createQuery("delete from Collaborator where emailid='"+email+"'");
		
		int s=query.executeUpdate();
		return 0;
	}

	@Override
	public List<Collaborator> getColabNotes(String token) {
		
		return null;
	}
	@Override
	public List<Collaborator> getColab(String emailid, Long noteid) {
		Session session = entityManager.unwrap(Session.class);
		//String emailide="vivekray037@gmail.com";
		Query<Collaborator> query = session.createQuery("from Collaborator where userid="+2L+" and note_id="+noteid, Collaborator.class);
		List<Collaborator> collabs = query.getResultList();
		return collabs;
	}

}
