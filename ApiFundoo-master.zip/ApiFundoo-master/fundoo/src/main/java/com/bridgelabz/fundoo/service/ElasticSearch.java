package com.bridgelabz.fundoo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.bridgelabz.fundoo.model.Note;
@Service
public interface ElasticSearch {
	String CreateNote(Note note);

	String UpdateNote(Note note);

	String DeleteNote(Note note);

	

	List<Note> searchbytitle(String title);

}

