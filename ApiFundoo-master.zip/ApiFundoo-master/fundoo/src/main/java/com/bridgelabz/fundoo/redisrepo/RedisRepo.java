package com.bridgelabz.fundoo.redisrepo;

import com.bridgelabz.fundoo.model.Note;

public interface RedisRepo {
 void save(Note note);
}
