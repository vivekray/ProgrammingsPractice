package com.bridgelabz.fundoo.serviceImpl;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.auth0.jwt.exceptions.JWTVerificationException;
import com.bridgelabz.fundoo.exception.UserException;
import com.bridgelabz.fundoo.model.Collaborator;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.model.User;
import com.bridgelabz.fundoo.repo.CollaboratorDAO;
import com.bridgelabz.fundoo.repo.NotesDAO;
import com.bridgelabz.fundoo.repo.UserDAO;
import com.bridgelabz.fundoo.service.CollaboratorService;
import com.bridgelabz.fundoo.util.TokenGeneration;
@Service
@Transactional
public class CollaboratorServiceImpl implements CollaboratorService {
	
	@Autowired
	private UserDAO repo;
	@Autowired
	private NotesDAO noteDao;
	@Autowired
	private TokenGeneration tokenGen;
	@Autowired
	private CollaboratorDAO coladao;
	@Override
	public int addCollaborator(Long noteId, String email, String token) {
		Collaborator cola=new Collaborator();
	   // Long userid=repo.checkUser(tokenGen.generateToken(token)).get(0).getId();
	    cola.setUserid(2L);
	    cola.setNoteId(noteId);
	    cola.setEmailid(email);
	    return coladao.addCollaborator(cola);
	    
	           
	}
	@Override
	public int removeCollaborator(Long noteId, String email, String token) {
		Collaborator cola=new Collaborator();
		cola.setEmailid(email);
		
		return coladao.removeCollaborator(noteId, email, token);
	}
	@Override
	public List<Collaborator> getColabNotes(String token) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Collaborator> getColab(String token, Long noteid) {
		
		  System.out.println("Collabo++++++++++"+coladao.getColab(token,noteid));
		return coladao.getColab(token,noteid);
	}
	
//	@Override
//	public Note addCollaborator(Long noteId, String email, String  token) {
//
//		User user;
//		//User  collaborator = repo.getUser(email);
//		boolean status=repo.isValidUser(email);
//		System.out.println(status);
//		try {
//			System.out.println("in service");
//			//Long userid = Long.parseLong(tokenGen.generateToken(token));
//			Long userid=2L;
//			System.out.println("inside note service" + userid);
//
//			user = repo.getUserById(userid);
//		}
//		
//		catch(Exception e) {
//			throw new UserException("user is not present with the given id ");
//		}
//		if(user !=null) {
//			if(status) {
//		
//				Note note=noteDao.getNoteById(noteId);
////				note.getColabUser().add(user);
////				user.getColaborateNote().add(note);
////				noteDao.save(note);
////				user.getColaborateNote().add(note);
////				repo.save(collaborator);
////				noteRepository.save(note);
//				return note;
//			}
//			else {
//				throw new UserException("user is not present with the given id ");
//			}
//		}
//		else {
//			throw new UserException("collorator not exist ");
//		}
//		
//		
//	}
//	@Override
//	public List<Note> getColabNotes(String token) throws JWTVerificationException, IllegalArgumentException, UnsupportedEncodingException{
//		
//		Long userid = Long.parseLong(tokenGen.generateToken(token));
//		User	user = repo.getUserById(userid);
//		//List<Note> notes=user.getColaborateNote();
//		return null;
//		
//		
//	}
//	@Override
//	public Note removeCollaborator(Long noteId, String email, String  token) {
//		User user;
//		//User  collaborator = repo.getUser(email);
//				boolean status=repo.isValidUser(email);
//		try {
//			System.out.println("in service");
//			Long userid = Long.parseLong(tokenGen.generateToken(token));
//			System.out.println("inside note service" + userid);
//
//			user = repo.getUserById(userid);
//		}
//		
//		catch(Exception e) {
//			throw new UserException("user is not present with the given id ");
//		}
//		Note note=noteDao.getNoteById(noteId);
//	//	note.getColabUser().remove(collaborator);
//
//		
//		
//		
//		
//		
////		UserInformation user;
////		UserInformation  collaborator = repository.getUser(email);
////		try {
////			System.out.println("in service");
////			Long userid = (long) tokenGenerator.parseJWT(token);
////			System.out.println("inside note service" + userid);
////
////			user = repository.getUserById(userid);
////		}
////		
////		catch(Exception e) {
////			throw new UserException("user is not present with the given id ");
////		}
////		if(user !=null) {
////			if(collaborator !=null) {
////				NoteInformation note=noteRepository.findById(noteId);
////				note.getCollabList().remove(collaborator);
////				noteRepository.save(note);
////				return note;
////			}
////			else {
////				throw new UserException("user is not present with the given id ");
////			}
////		}
////		else {
////			throw new UserException("collorator not exist ");
////		}
////		
//	return null;
//	}


}



