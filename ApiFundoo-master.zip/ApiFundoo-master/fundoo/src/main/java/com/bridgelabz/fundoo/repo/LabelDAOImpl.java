package com.bridgelabz.fundoo.repo;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bridgelabz.fundoo.model.Label;
import com.bridgelabz.fundoo.model.Note;
@Repository
public class LabelDAOImpl implements LabelDAO {


	@Autowired
	private EntityManager entityManager;
	@Override
	public Label save(Label labelInformation) {

		Session session = entityManager.unwrap(Session.class);
		session.save(labelInformation);
		return labelInformation;
	}
	@Override
	public Note saveNote(Note notes) {

		Session session = entityManager.unwrap(Session.class);
		session.save(notes);
		return notes;
	}
	
	@Override
	public Label fetchLabel(Long userid, String labelname) {

		Session session = entityManager.unwrap(Session.class);
		Query q = session.createQuery("from Label where user_id=:id and name=:name");
		q.setParameter("id", userid);
		q.setParameter("name", labelname);
		return (Label) q.uniqueResult(); 

	}
	@Override
	public Label fetchLabelById(Long id) {

		Session session = entityManager.unwrap(Session.class);
		Query q = session.createQuery("from Label where label_id=:id");
		q.setParameter("id", id);

		return (Label) q.uniqueResult();

	}
	@Override
	public int deleteLabel(Long i) {
		String hql = "DELETE FROM Label " + "WHERE label_id = :id";
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createQuery(hql);
		query.setParameter("id", i);
		int result = query.executeUpdate();
		return result;
	}
	@Override
	public List<Label> getAllLabel(Long id)
	{
		String hql = "FROM Label " + "WHERE user_id=:id";
		Session session = entityManager.unwrap(Session.class);
		//Query query = session.createQuery(hql);
		return session.createQuery("from Label where user_id="+id).getResultList();
		/*
		 * query.setParameter("id", id); return query.getResultList();
		 */
	}
	@Override
	public Label getLabel(Long id)
	{
		String hql = "FROM Label " + "WHERE label_id=:id";
		Session session = entityManager.unwrap(Session.class);
		//Query query = session.createQuery(hql);
		return (Label) session.createQuery("from Label where label_id='"+id+"'").uniqueResult();
		/*
		 * query.setParameter("id", id); return query.getResultList();
		 */
	}
	
}
