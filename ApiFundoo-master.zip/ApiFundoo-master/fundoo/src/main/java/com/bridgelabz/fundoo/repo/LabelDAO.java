package com.bridgelabz.fundoo.repo;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.bridgelabz.fundoo.model.Label;
import com.bridgelabz.fundoo.model.Note;

public interface LabelDAO {
	
	public Label save(Label label);
	public Note saveNote(Note notes);	
    public Label fetchLabel(Long userid, String labelname) ;
	public Label fetchLabelById(Long id) ;
	public int deleteLabel(Long i) ;
	public List<Label> getAllLabel(Long id);
	public Label getLabel(Long id);
}
