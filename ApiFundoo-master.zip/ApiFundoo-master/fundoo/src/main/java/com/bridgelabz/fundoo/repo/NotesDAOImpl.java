package com.bridgelabz.fundoo.repo;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bridgelabz.fundoo.model.Note;

@Repository
public class NotesDAOImpl implements NotesDAO {
	@Autowired
	private EntityManager entityManager;


	@Override
	public List<Note> getAllNote(Long userid) {
		boolean status=false;
	
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Note> query = currentSession.createQuery("from Note where userid='"+userid+"' and is_trashed="+status+" and is_archieved="+status, Note.class);
		List<Note> NoteList = query.getResultList();
		return NoteList;
		
	}
	

	@Override
	public List<Note> getTrashedNote(Long userid) {
	Boolean status=true;
	Session session = entityManager.unwrap(Session.class);
	Note note = session.get(Note.class, userid);

		Session currentSession = entityManager.unwrap(Session.class);
		Query<Note> query = currentSession.createQuery("from Note where userid="+userid+"and is_trashed="+status, Note.class);
		List<Note> NoteList = query.getResultList();
		return NoteList;
	
	}



	@Override
	public List<Note> getArchiveNote(Long userid) {
		boolean status=true;
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Note> query = currentSession.createQuery("from Note where userid='"+userid+"'and is_archieved="+status, Note.class);
		List<Note> NotesInformationsList = query.getResultList();
		return NotesInformationsList;
		
	}
	
	
	@Override
	public List<Note> getPinnedNote(Long userid) {
		boolean status=true;
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Note> query = currentSession.createQuery("from Note where userid='"+userid+"'and is_pinned="+status, Note.class);
		List<Note> NotesInformationsList = query.getResultList();
		return NotesInformationsList;
		
	}
	@Override
	public List<Note> getReminder(Long userid){
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Note> query = currentSession.createQuery("from Note where userid='"+userid+"'and reminder is not null", Note.class);
		List<Note> NotesInformationsList = query.getResultList();
		return NotesInformationsList;
	}






	@Override
	public Note getNoteById(Long userId) {
		Session currentSession = entityManager.unwrap(Session.class);
		Note note = currentSession.get(Note.class, userId);
		return note;
	}

	@Override
	public int createNote(Note notes) {
		Session currentSession = entityManager.unwrap(Session.class);

		//if (!isValidUser(user.getEmail())) {
		currentSession.save(notes);
		return 1;
	}
	@Override
	public Note save(Note note) {

		Session session = entityManager.unwrap(Session.class);

		session.saveOrUpdate(note);
		System.out.println("color in repo"+note.getColor());
		return note;

	}
	
	
	@Override
	public int deleteNote(Long userId) {
		  try {
				Session currentSession = entityManager.unwrap(Session.class);
				Note note = currentSession.get(Note.class, userId);
				currentSession.delete(note);
				
				return 1;
		        } catch (Exception e) {
					// TODO: handle exception
		        	return 0;
		        }
	}

	@Override
	public int updateNote(Note note) {
		Session session = entityManager.unwrap(Session.class);

		session.saveOrUpdate(note);
		return 1;
	}
	
	
	@Override
	public int archievNote(Long id, Long token) {
		Boolean status=true;
		Session session = entityManager.unwrap(Session.class);
		Note note = session.get(Note.class, id);
	
		if(note.isArchieved()) {
	    	status=false;
	    }
	    int s = session.createQuery("update Note set is_archieved=" + status + " where id=" + id)
				.executeUpdate();
		if(s>0)
		return 1;
		else
			return 0;
	}



	@Override
	public int pin(long id, Long token) {
		Boolean status=true,status1=false;
		Session session = entityManager.unwrap(Session.class);
		Note note = session.get(Note.class, id);
	
		if(note.isPinned()) {
	    	status=false;
	    }
		int s = 0;		
		s = session.createQuery("update Note set is_pinned=" + status +",is_archieved=" + status1 +",is_trashed=" + status1 +" where id=" + id)
				.executeUpdate();
		if(s>0)
		return 1;
		else
			return 0;
		
	}
	@Override
	public int trashNote(Long id, Long token) {
		Boolean status=true;
		Session session = entityManager.unwrap(Session.class);
		Note note = session.get(Note.class, id);
	
		if(note.isTrashed()) {
	    	status=false;
	    }
	   int s = session.createQuery("update Note set is_trashed=" + status + " where id=" + id)
				.executeUpdate();
	
		if(s>0)
			return 1;
			else
				return 0;
		
	}


	@Override
	public int reminder(Long id, String token,LocalDateTime reminder) {
		Session session = entityManager.unwrap(Session.class);
		Note note = session.get(Note.class, id);
	
	   int s = session.createQuery("update Note set reminder=" + reminder + " where id=" + id)
				.executeUpdate();
	
		if(s>0)
			return 1;
			else
				return 0;
		
	}
	}





	



	

	

