package com.bridgelabz.fundoo.serviceImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundoo.config.JeddisConnection;
import com.bridgelabz.fundoo.dto.NotesDto;
import com.bridgelabz.fundoo.exception.UserException;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.model.NoteUpdation;
import com.bridgelabz.fundoo.redisrepo.RedisRepo;
import com.bridgelabz.fundoo.repo.NotesDAO;
import com.bridgelabz.fundoo.repo.NotesDAOImpl;
import com.bridgelabz.fundoo.service.ElasticSearch;
import com.bridgelabz.fundoo.service.NoteService;
import com.bridgelabz.fundoo.util.TokenGeneration;
import com.bridgelabz.fundoo.util.Utility;
@Service
@Transactional
public class NoteServiceImpl implements NoteService {

	@Autowired
	private NotesDAO noteDao;
	
	@Autowired
	private TokenGeneration token;
	@Autowired
	private JeddisConnection redisConnection;
	
	@Autowired
	private RedisRepo redisRepository;
	@Autowired
	private ElasticSearch elasticSearch;

	
	@Override
	public List<NotesDto> getAllNote(String tokens) {
		//Here accept value as token,convert and take as Long input
		return (Utility.convertNoteToNotesDto(noteDao.getAllNote(Long.parseLong(token.parseToken(tokens)))));

	}

	
	@Override
	public NotesDto getNoteById(Long userId, String error) {
		if (noteDao.getNoteById(userId)==null) {
			throw new UserException(error);
		}
		return Utility.noteToNotesDto(noteDao.getNoteById(userId));
	}

	@Override
	public NotesDto createNote(NotesDto notes,String id) {
		Note note=Utility.noteDtoToNote(notes);
		///Here accept value as token and parse and pass as id
		note.setUserid(Long.parseLong(token.parseToken(id)));
		if(noteDao.createNote(note)>0){
		
			System.out.println("save yrr"+notes);
		//	String check1 = elasticSearch.CreateNote(note);
			//System.out.println("Elasticserech------>>>"+check1);
			
			
			
			 String useid=note.getUserid().toString();
			if(note!=null) {
				final String KEY=useid;
				try {
					redisConnection.redistemplate().opsForValue().set(KEY, note.toString());
					redisRepository.save(note);
					String check1 = elasticSearch.CreateNote(note);
					System.out.println("Elasticserech------>>>"+check1);
					System.out.println(check1);
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			return  notes;
			
		}
		else {
			throw new UserException("Not created");
		}
		
	
	}

	@Override
	public int deleteNote(Long userId) {
		// TODO Auto-generated method stub
		return noteDao.deleteNote(userId);

	}

	@Override
	public int updateNote() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public void updateNote(NoteUpdation info, String tokens) {
		Note note = new Note();
		note.setNoteId(info.getId());
		note.setTitle(info.getTitle());
		note.setDescription(info.getDescription());
		note.setArchieved(info.isArchieved());
		note.setPinned(info.isPinned());
		note.setTrashed(info.isTrashed());
		note.setColor(info.getColor());
		note.setUserid(Long.parseLong(token.parseToken(tokens)));
		LocalDateTime date=LocalDateTime.now();
		note.setUpDateAndTime(date);
		 
		int s=noteDao.updateNote(note);
		
	}




	
	
	@Override
	public List<NotesDto> getArchiveNote(String tokens) {
		return (Utility.convertNoteToNotesDto(noteDao.getArchiveNote(Long.parseLong(token.parseToken(tokens)))));
	
	}
	
	@Override
	public List<NotesDto> getAllReminders(String tokens){
		return (Utility.convertNoteToNotesDto(noteDao.getReminder(Long.parseLong(token.parseToken(tokens)))));
	}


	@Override
	public List<NotesDto> getTrashedNotes(String tokens) {
		return (Utility.convertNoteToNotesDto(noteDao.getTrashedNote(Long.parseLong(token.parseToken(tokens)))));
	
	}


	@Override
	public boolean deleteNotePemenetly(long id, String token) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void archievNote(long id, String tokens) {
		int s=noteDao.archievNote(id, Long.parseLong(token.parseToken(tokens)));
		
	}

	@Override
	public void trashNote(Long id, String tokens) {
		int s=noteDao.trashNote(id, Long.parseLong(token.parseToken(tokens)));
		
	}


	


	@Override
	public void addColour(Long noteId, String token, String colour) {
		Note note=noteDao.getNoteById(noteId);
		 note.setColor(colour);
		 System.out.println("color"+note.getColor());
		 noteDao.save(note);
		
	}


	@Override
	public void addReminder(Long noteId, String token, String reminder) {
		Note note=noteDao.getNoteById(noteId);
		  // localDateTime = LocalDateTime.parse("Sat, Dec 28 2019 08:00:00");
	      //DateFormat df6 = new SimpleDateFormat("E, MMM dd yyyy HH:mm:ss");
	        DateTimeFormatter format = DateTimeFormatter.ofPattern("E MMM dd yyyy HH:mm:ss");
	        LocalDateTime dateTime = LocalDateTime.parse(reminder, format);
		    note.setReminder(dateTime);
		 noteDao.save(note);
		
	}


	@Override
	public void removeReminder(Long noteId, String token, String reminder) {
		Note note=noteDao.getNoteById(noteId);
		 note.setReminder(null);
		 noteDao.save(note);
		
	}


	@Override
	public void pin(long id, String tokens) {
		int s=noteDao.pin(id, Long.parseLong(token.parseToken(tokens)));
		
	}


	@Override
	public List<NotesDto> searchByTitle(String title) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<NotesDto> getAllPinnedNotes(String tokens) {
		return (Utility.convertNoteToNotesDto(noteDao.getPinnedNote(Long.parseLong(token.parseToken(tokens)))));
		
	}
	
	/////////////////////////////////////////////////////////
	
	
}
