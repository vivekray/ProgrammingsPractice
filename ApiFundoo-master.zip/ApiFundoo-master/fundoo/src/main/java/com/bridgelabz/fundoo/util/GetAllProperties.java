package com.bridgelabz.fundoo.util;

import java.io.FileInputStream;
import java.util.Properties;
public class GetAllProperties {
	
	public static void getProperties() {
		Properties pro=new Properties();
		System.out.println("Keysssssssssss");
		try {
			FileInputStream in=new FileInputStream("messages.properties");
			pro.load(in);
			System.out.println("Keysssssssssss");
			System.out.print(pro.keySet());
			
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

}
