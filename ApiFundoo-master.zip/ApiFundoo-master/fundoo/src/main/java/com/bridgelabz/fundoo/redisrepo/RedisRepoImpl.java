package com.bridgelabz.fundoo.redisrepo;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.bridgelabz.fundoo.model.Note;

@Repository
public class RedisRepoImpl implements RedisRepo {
    private static final String KEY = "notes";
   
	private RedisTemplate<String, Object> redisTemplate;

    private HashOperations<String, Long, Object> hashOperations;


    public RedisRepoImpl(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;

        hashOperations = redisTemplate.opsForHash();
    }
	 
	 public void save(Note note) {
		// System.out.println("note"+ "  "+note);
	        hashOperations.put(KEY, note.getNoteId(), note.toString());
	        System.out.println("Redis saved Data"+note);
	    }

}
