package com.bridgelabz.fundoo.serviceImpl;

import java.util.List;

import javax.persistence.Column;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundoo.dto.LabelDto;
import com.bridgelabz.fundoo.exception.UserException;
import com.bridgelabz.fundoo.model.Label;
import com.bridgelabz.fundoo.model.Note;
import com.bridgelabz.fundoo.model.User;
import com.bridgelabz.fundoo.repo.LabelDAO;
import com.bridgelabz.fundoo.repo.NotesDAO;
import com.bridgelabz.fundoo.repo.UserDAO;
import com.bridgelabz.fundoo.service.LabelService;
import com.bridgelabz.fundoo.util.TokenGeneration;

@Service
@Transactional
public class LabelServiceImpl implements LabelService {

	@Autowired
	private LabelDAO repository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Label labelInformation;

	@Autowired
	private UserDAO userRepository;
	@Autowired
	private NotesDAO NotesDAO;

	@Autowired
	private TokenGeneration tokenGenerator;

	@Override
	public void createLabel(LabelDto label, String token) {
		// TODO Auto-generated method stub
		Long id = null;

		try {
			id =Long.parseLong(tokenGenerator.parseToken(token));
		} catch (Exception e) {

			throw new UserException("user is not present ");
		}

		User user = userRepository.getUserById(id);
		if (user != null) {
			Label labelInfo = repository.fetchLabel(user.getId(), label.getName());
			if (labelInfo == null) {
				labelInformation = modelMapper.map(label, Label.class);
				labelInformation.getLabelId();
				labelInformation.getName();
				labelInformation.setUserId(user.getId());
				repository.save(labelInformation);
			} else {
				throw new UserException("label is already present");
			}
		} else {
			throw new UserException("note is not present with the given id ");
		}

	}

	@Override
	public List<Label> getLabel(String token) {

		Long id;
		try {
			id = Long.parseLong(tokenGenerator.parseToken(token));
		} catch (Exception e) {

			throw new UserException("note not present ");
		}

		List<Label> labels = repository.getAllLabel(id);
		return labels;
	}

	@Override
	public List<Note> getAllNotes(String token, Long labelId) {
		Label label=repository.getLabel(labelId);
		//List<Note> list=
		List<Note> list=label.getList();
		
		System.out.println("label is"+list);
		
		return list;
	}
	
	@Override
	public void addLabel(Long labelId, Long noteId, String token) {
		Note note = NotesDAO.getNoteById(noteId);
		Label label = repository.fetchLabelById(labelId);
		label.getList().add(note);
		repository.save(label);
		
	}

	@Override
	public void removeLabel(Long labelId, Long noteId, String token) {
		Note note = NotesDAO.getNoteById(noteId);
		Label label = repository.fetchLabelById(labelId);
		note.getList().remove(label);
		
		NotesDAO.createNote(note);

	}

	@Override
	public void createLabelAndMap(LabelDto label, String token, Long noteId) {
		Long id = null;

		try {
			id = Long.parseLong(tokenGenerator.parseToken(token));
		} catch (Exception e) {

			throw new UserException("user is not present ");
		}

		User user = userRepository.getUserById(id);
		if (user != null) {
			Label labelInfo = repository.fetchLabel(user.getId(), label.getName());
			if (labelInfo == null) {
				labelInformation = modelMapper.map(label, Label.class);
//				labelInformation.getLabelId();
//				labelInformation.getName();
				labelInformation.setUserId(user.getId());
				repository.save(labelInformation);
				Note note = NotesDAO.getNoteById(3L);//noteId
				note.getList().add(labelInformation);
				NotesDAO.createNote(note);

			} else {
				throw new UserException("label is already present");
			}
		} else {
			throw new UserException("note is not present with the given id ");
		}

	}

	

}
