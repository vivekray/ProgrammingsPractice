package com.bridgelabz.fundoo.repo;

import java.util.List;

import com.bridgelabz.fundoo.model.Collaborator;

public interface CollaboratorDAO {
	int addCollaborator(Collaborator collaborator);
	   int removeCollaborator(Long noteId, String email, String token);
	  List<Collaborator> getColabNotes(String token);
	  List<Collaborator> getColab(String token, Long noteid);
}
