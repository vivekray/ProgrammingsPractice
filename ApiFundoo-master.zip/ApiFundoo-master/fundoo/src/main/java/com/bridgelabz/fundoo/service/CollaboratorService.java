package com.bridgelabz.fundoo.service;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.auth0.jwt.exceptions.JWTVerificationException;
import com.bridgelabz.fundoo.model.Collaborator;
import com.bridgelabz.fundoo.model.Note;

public interface CollaboratorService {
	
	  int addCollaborator(Long noteId, String email, String token);
	   int removeCollaborator(Long noteId, String email, String token);
	  List<Collaborator> getColabNotes(String token);
	  List<Collaborator> getColab(String token,Long noteid);
	
//	Note addCollaborator(Long noteId, String email, String token);
//
//	Note removeCollaborator(Long noteId, String email, String token);
//
//	List<Note> getColabNotes(String token)
//			throws JWTVerificationException, IllegalArgumentException, UnsupportedEncodingException;

}

