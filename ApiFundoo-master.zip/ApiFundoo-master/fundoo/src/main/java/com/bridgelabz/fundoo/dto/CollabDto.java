package com.bridgelabz.fundoo.dto;

import lombok.Data;

@Data
public class CollabDto {
  private Long noteid;
  private String emailid;
}
