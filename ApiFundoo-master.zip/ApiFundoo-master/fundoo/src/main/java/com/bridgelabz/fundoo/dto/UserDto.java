package com.bridgelabz.fundoo.dto;

import java.time.LocalDateTime;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Data
//@NoArgsConstructor
//@AllArgsConstructor
@PropertySource("classpath:messages.properties")
public class UserDto {
	
	
	String PASSWORD_PATTERN = "^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$";
	
	@Pattern(regexp ="[A-Za-z]{3,10}",message ="FirstName Must be Start With Capital with Minimum 8 Character")
    private String firstName;
	@Pattern(regexp ="[A-Za-z]{3,10}",message ="LastName Must be Start With Capital with Minimum 8 Character")
	private String lastName;
	
	//@Pattern(regexp = "[789]{1}[0-9]{9}",message = "Number Should be 10 digit Start with 789")
//	@Size(min = 10,max=10,message = "Number Should be 10 disgit")
	private Long mobileNumber;
	
	
	@Pattern(regexp ="^(.+)@(.+)$",message ="Invalid Email Id")
	private String email;
	@Pattern(regexp = "^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$",message = "Password must be Combination of of Alphabet,Symbol and Number with Mainimum 8 disgts")
	private String password;
	private LocalDateTime createdTime;
	private LocalDateTime updatedTime;

	public LocalDateTime getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(LocalDateTime updatedTime) {
		this.updatedTime = updatedTime;
	}

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	

	public UserDto() {
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
	this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}